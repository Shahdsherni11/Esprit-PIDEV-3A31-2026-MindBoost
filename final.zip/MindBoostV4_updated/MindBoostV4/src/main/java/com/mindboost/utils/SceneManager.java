package com.mindboost.utils;

import com.mindboost.controllers.FaceLoginController;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class SceneManager {

    private static Stage  primaryStage;
    private static Object currentController;

    public static void setPrimaryStage(Stage stage) { primaryStage = stage; }
    public static Stage getPrimaryStage()           { return primaryStage; }

    /**
     * Change la scène en nettoyant proprement le contrôleur actuel.
     */
    public static void switchTo(String fxmlPath) {
        cleanupCurrentController();
        try {
            FXMLLoader loader = new FXMLLoader(SceneManager.class.getResource(fxmlPath));
            Parent root = loader.load();
            currentController = loader.getController();

            Scene scene = new Scene(root);
            scene.getStylesheets().add(
                SceneManager.class.getResource("/com/mindboost/css/mindboost.css").toExternalForm()
            );
            primaryStage.setScene(scene);
            primaryStage.centerOnScreen();
        } catch (Exception e) {
            System.err.println("❌ SceneManager: impossible de charger " + fxmlPath);
            e.printStackTrace();
        }
    }

    public static <T> T switchToWithController(String fxmlPath) {
        cleanupCurrentController();
        try {
            FXMLLoader loader = new FXMLLoader(SceneManager.class.getResource(fxmlPath));
            Parent root = loader.load();
            currentController = loader.getController();

            Scene scene = new Scene(root);
            scene.getStylesheets().add(
                SceneManager.class.getResource("/com/mindboost/css/mindboost.css").toExternalForm()
            );
            primaryStage.setScene(scene);
            primaryStage.centerOnScreen();
            return loader.getController();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /** Libère les ressources du contrôleur courant (caméra, threads...) */
    private static void cleanupCurrentController() {
        if (currentController instanceof FaceLoginController fc) {
            fc.stopCamera();
        }
        currentController = null;
    }

    /** Appelé à la fermeture de l'application */
    public static void cleanup() {
        cleanupCurrentController();
    }
}
