package com.mindboost.services;

import com.google.gson.*;
import okhttp3.*;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Service MindBot — Groq API (100% gratuit, ultra-rapide, pas de CB)
 *
 * ✅ GRATUIT : https://console.groq.com → Sign up → API Keys → Create API Key
 * ✅ Pas de carte bancaire requise
 * ✅ Modèle : llama-3.1-8b-instant (rapide + puissant)
 * ✅ Limites gratuites généreuses : 6000 req/min, 500k tokens/jour
 *
 * Alternative locale 100% gratuite sans clé : Ollama (voir ci-dessous)
 */
public class GroqAIService {

    private static String API_KEY = System.getProperty("GROQ_API_KEY", "YOUR_GROQ_KEY_HERE");
    private static final String GROQ_URL  = "https://api.groq.com/openai/v1/chat/completions";
    private static final String OLLAMA_URL = "http://localhost:11434/api/chat";

    // Modèle Groq gratuit — rapide et performant
    private static final String GROQ_MODEL   = "llama-3.1-8b-instant";
    private static final String OLLAMA_MODEL  = "llama3.2";

    private static final OkHttpClient client = new OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build();

    public static void setApiKey(String key) {
        API_KEY = key;
    }

    // ─────────────────────────────────────────
    //  Point d'entrée principal
    // ─────────────────────────────────────────
    public static String chat(String userMessage, String psychContext,
                              List<Map<String, String>> history) throws IOException {

        // 1) Essayer Ollama (local, totalement gratuit, aucune clé)
        try {
            String ollamaResp = callOllama(userMessage, psychContext, history);
            if (ollamaResp != null) return ollamaResp;
        } catch (Exception ignored) {
            // Ollama non installé → on passe à Groq
        }

        // 2) Groq API (gratuit avec clé)
        if (API_KEY == null || API_KEY.isBlank()
                || API_KEY.equals("YOUR_GROQ_KEY_HERE")) {
            return "🤖 MindBot — Configuration rapide requise !\n\n"
                + "Option A — Gratuit en ligne (Groq) :\n"
                + "  1. Aller sur console.groq.com\n"
                + "  2. Créer un compte gratuit (pas de CB)\n"
                + "  3. API Keys → Create Key\n"
                + "  4. Coller dans config.properties : GROQ_API_KEY=gsk_...\n\n"
                + "Option B — 100% local (Ollama) :\n"
                + "  1. Installer ollama.com\n"
                + "  2. Lancer : ollama pull llama3.2\n"
                + "  3. Aucune clé requise !\n\n"
                + "Relancez l'application après configuration.";
        }

        return callGroq(userMessage, psychContext, history);
    }

    // ─────────────────────────────────────────
    //  Appel Groq (OpenAI-compatible)
    // ─────────────────────────────────────────
    private static String callGroq(String userMessage, String psychContext,
                                   List<Map<String, String>> history) throws IOException {
        JsonArray messages = buildMessages(userMessage, psychContext, history);

        JsonObject body = new JsonObject();
        body.addProperty("model", GROQ_MODEL);
        body.add("messages", messages);
        body.addProperty("max_tokens", 300);
        body.addProperty("temperature", 0.7);

        Request request = new Request.Builder()
            .url(GROQ_URL)
            .addHeader("Authorization", "Bearer " + API_KEY)
            .addHeader("Content-Type", "application/json")
            .post(RequestBody.create(body.toString(), MediaType.get("application/json")))
            .build();

        try (Response response = client.newCall(request).execute()) {
            ResponseBody respBody = response.body();
            if (!response.isSuccessful() || respBody == null) {
                int code = response.code();
                if (code == 401) return "❌ Clé Groq invalide. Vérifiez GROQ_API_KEY dans config.properties.";
                if (code == 429) return "⏳ Limite Groq atteinte. Attendez quelques secondes et réessayez.";
                return "⚠️ MindBot indisponible (HTTP " + code + "). Réessayez.";
            }

            String raw = respBody.string();
            JsonObject json = JsonParser.parseString(raw).getAsJsonObject();

            if (json.has("error")) {
                String err = json.getAsJsonObject("error").get("message").getAsString();
                return "⚠️ Erreur Groq: " + err;
            }

            return json.getAsJsonArray("choices")
                .get(0).getAsJsonObject()
                .getAsJsonObject("message")
                .get("content").getAsString().trim();
        }
    }

    // ─────────────────────────────────────────
    //  Appel Ollama local (aucune clé requise)
    // ─────────────────────────────────────────
    private static String callOllama(String userMessage, String psychContext,
                                     List<Map<String, String>> history) throws IOException {
        JsonArray messages = buildMessages(userMessage, psychContext, history);

        JsonObject body = new JsonObject();
        body.addProperty("model", OLLAMA_MODEL);
        body.add("messages", messages);
        body.addProperty("stream", false);

        Request request = new Request.Builder()
            .url(OLLAMA_URL)
            .addHeader("Content-Type", "application/json")
            .post(RequestBody.create(body.toString(), MediaType.get("application/json")))
            .build();

        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful() || response.body() == null) return null;
            String raw = response.body().string();
            JsonObject json = JsonParser.parseString(raw).getAsJsonObject();
            if (json.has("message")) {
                return json.getAsJsonObject("message").get("content").getAsString().trim();
            }
            return null;
        }
    }

    // ─────────────────────────────────────────
    //  Construction du tableau de messages
    // ─────────────────────────────────────────
    private static JsonArray buildMessages(String userMessage, String psychContext,
                                           List<Map<String, String>> history) {
        JsonArray messages = new JsonArray();

        // Système
        JsonObject system = new JsonObject();
        system.addProperty("role", "system");
        system.addProperty("content",
            "Tu es MindBot, un assistant psychologique bienveillant et empathique de MindBoost. "
            + "Tu parles TOUJOURS en français. Tu adaptes ton ton selon le profil de l'utilisateur. "
            + "Contexte psychologique actuel: " + (psychContext != null ? psychContext : "Non disponible") + ". "
            + "Réponds avec empathie, de façon concise (max 150 mots), propose des exercices pratiques si pertinent. "
            + "Ne diagnostique JAMAIS, oriente vers un professionnel si nécessaire. "
            + "Réponds uniquement en français, jamais en anglais.");
        messages.add(system);

        // Historique (8 derniers)
        int start = Math.max(0, history.size() - 8);
        for (int i = start; i < history.size(); i++) {
            Map<String, String> msg = history.get(i);
            if (msg.get("role") == null || msg.get("content") == null) continue;
            JsonObject m = new JsonObject();
            m.addProperty("role", msg.get("role"));
            m.addProperty("content", msg.get("content"));
            messages.add(m);
        }

        // Message actuel
        JsonObject userMsg = new JsonObject();
        userMsg.addProperty("role", "user");
        userMsg.addProperty("content", userMessage);
        messages.add(userMsg);

        return messages;
    }
}
