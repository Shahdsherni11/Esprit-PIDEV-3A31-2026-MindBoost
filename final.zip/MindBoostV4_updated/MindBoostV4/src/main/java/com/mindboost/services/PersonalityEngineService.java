package com.mindboost.services;

import com.mindboost.dao.BehaviorDAO;
import com.mindboost.dao.PsychProfileDAO;
import com.mindboost.models.BehaviorEvent;
import com.mindboost.models.PsychProfile;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/**
 * 🧬 Moteur de détection de personnalité par comportement
 *
 * CE QUE CE MOTEUR MESURE RÉELLEMENT :
 *
 * 1. VITESSE ET RÉGULARITÉ DE FRAPPE
 *    Frappe rapide régulière → concentration (focus↑)
 *    Frappe erratique        → distraction/stress (anxiety↑)
 *    Frappe lente régulière  → réflexif (resilience↑)
 *
 * 2. PAUSES D'INACTIVITÉ (> 3 secondes)
 *    Pauses courtes fréquentes → pensée réflexive (resilience↑)
 *    Longues pauses nombreuses → hésitation (anxiety↑)
 *    Peu de pauses            → fluidité (mood↑)
 *
 * 3. RYTHME DE CLICS PAR MINUTE
 *    Rapide (>20/min) → impulsif/extraverti (sociability↑)
 *    Lent (<4/min)   → introverti/réfléchi (focus↑)
 *
 * 4. PATTERNS DE NAVIGATION
 *    Aller-retours fréquents → indécision (anxiety↑)
 *    Navigation directe      → décisif (focus↑, resilience↑)
 *    Visites introspectives  → conscience de soi (resilience↑, mood↑)
 *
 * 5. DURÉE ET ENGAGEMENT DE SESSION
 *    Session longue/productive → engagement positif (mood↑)
 *    Déconnexion rapide        → désengagement (mood↓ légèrement)
 *
 * NOTE : Ce sont des HEURISTIQUES comportementales, pas des diagnostics cliniques.
 *        Les scores changent graduellement (+2 à +5 pts max par analyse).
 *        Après ~5-10 sessions, les tendances deviennent significatives.
 */
public class PersonalityEngineService {

    private final BehaviorDAO     behaviorDAO = new BehaviorDAO();
    private final PsychProfileDAO psychDAO    = new PsychProfileDAO();

    // Buffers de collecte
    private final List<Long>   typingIntervals = new ArrayList<>();
    private final List<Long>   pauseDurations  = new ArrayList<>();
    private final List<String> navSequence     = new ArrayList<>();
    private int clickCount  = 0;
    private int actionCount = 0;

    private long sessionStart;
    private long lastKeyTime    = 0;
    private long lastActionTime;

    private final int    userId;
    private final String sessionId;

    // Analyse périodique automatique (toutes les 5 minutes)
    private ScheduledExecutorService scheduler;
    private Consumer<PsychProfile> onProfileUpdated; // callback → rafraîchit l'UI

    public PersonalityEngineService(int userId) {
        this.userId         = userId;
        this.sessionId      = UUID.randomUUID().toString().substring(0, 8);
        this.sessionStart   = System.currentTimeMillis();
        this.lastActionTime = sessionStart;
    }

    /**
     * Démarre l'analyse automatique périodique.
     * @param callback appelé sur le thread JavaFX après chaque analyse
     */
    public void startPeriodicAnalysis(Consumer<PsychProfile> callback) {
        this.onProfileUpdated = callback;
        scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "personality-engine-" + userId);
            t.setDaemon(true);
            return t;
        });
        // Première analyse après 3 minutes, puis toutes les 5 minutes
        scheduler.scheduleAtFixedRate(this::runPeriodicAnalysis, 3, 5, TimeUnit.MINUTES);
    }

    private void runPeriodicAnalysis() {
        // Ne déclenche l'analyse que s'il y a assez de données
        if (actionCount < 5) return;
        try {
            PsychProfile updated = analyzeAndUpdate();
            if (onProfileUpdated != null) {
                javafx.application.Platform.runLater(() -> onProfileUpdated.accept(updated));
            }
        } catch (Exception e) {
            System.err.println("⚠️ Periodic analysis error: " + e.getMessage());
        }
    }

    /** Arrête le scheduler (appeler à la déconnexion) */
    public void stop() {
        if (scheduler != null && !scheduler.isShutdown()) {
            scheduler.shutdownNow();
        }
    }

    // ── Collecte d'événements ─────────────────────────────────────────────

    /** À appeler sur chaque touche pressée dans N'IMPORTE QUEL champ de l'app */
    public void recordKeyPress() {
        long now = System.currentTimeMillis();
        if (lastKeyTime > 0) {
            long interval = now - lastKeyTime;
            if (interval > 30 && interval < 3000) {
                typingIntervals.add(interval);
            }
        }
        lastKeyTime = now;
        checkPause(now);
        lastActionTime = now;
        actionCount++;
    }

    /** À appeler sur chaque clic significatif de l'app */
    public void recordClick(String elementId) {
        clickCount++;
        actionCount++;
        long now = System.currentTimeMillis();
        checkPause(now);
        lastActionTime = now;
        try {
            behaviorDAO.save(new BehaviorEvent(userId, "click",
                "{\"element\":\"" + elementId + "\",\"count\":" + clickCount + "}", sessionId));
        } catch (Exception e) {
            System.err.println("BehaviorDAO: " + e.getMessage());
        }
    }

    /** À appeler à chaque changement d'écran/vue */
    public void recordNavigation(String screen) {
        navSequence.add(screen);
        actionCount++;
        long now = System.currentTimeMillis();
        checkPause(now);
        lastActionTime = now;
        try {
            behaviorDAO.save(new BehaviorEvent(userId, "navigation",
                "{\"screen\":\"" + screen + "\"}", sessionId));
        } catch (Exception e) {
            System.err.println("BehaviorDAO: " + e.getMessage());
        }
    }

    private void checkPause(long now) {
        long gap = now - lastActionTime;
        if (gap > 3000 && gap < 120_000) {
            pauseDurations.add(gap);
            try {
                behaviorDAO.save(new BehaviorEvent(userId, "pause",
                    "{\"duration_ms\":" + gap + "}", sessionId));
            } catch (Exception e) {
                System.err.println("BehaviorDAO: " + e.getMessage());
            }
        }
    }

    // ── Analyse et mise à jour du profil ─────────────────────────────────

    /**
     * Analyse les comportements collectés depuis la dernière analyse
     * et met à jour le profil psychologique de manière cumulative et graduelle.
     * Sauvegarde aussi un snapshot dans l'historique.
     */
    public PsychProfile analyzeAndUpdate() throws Exception {
        PsychProfile profile = psychDAO.getByUserId(userId);
        if (profile == null) profile = new PsychProfile(userId);

        if (actionCount < 3 && typingIntervals.isEmpty()) return profile;

        // ── 1. VITESSE ET RÉGULARITÉ DE FRAPPE ───────────────────────────
        if (typingIntervals.size() >= 5) {
            double avgMs  = typingIntervals.stream().mapToLong(Long::longValue).average().orElse(200);
            double stdDev = standardDeviation(typingIntervals);
            double cv     = stdDev / Math.max(avgMs, 1); // coefficient de variation

            if (avgMs < 120 && cv < 0.4) {
                // Frappe très rapide et régulière → forte concentration
                profile.setFocus(profile.getFocus() + 5);
                profile.setAnxiety(profile.getAnxiety() - 2);
                profile.setMood(profile.getMood() + 1);
            } else if (avgMs < 200 && cv < 0.6) {
                // Frappe normale régulière → bonne concentration
                profile.setFocus(profile.getFocus() + 2);
            } else if (cv > 0.8 || avgMs > 500) {
                // Frappe très irrégulière ou très lente → stress/distraction
                profile.setFocus(profile.getFocus() - 3);
                profile.setAnxiety(profile.getAnxiety() + 3);
            } else if (avgMs > 300 && cv < 0.5) {
                // Frappe lente mais régulière → personnalité réfléchie
                profile.setResilience(profile.getResilience() + 2);
                profile.setFocus(profile.getFocus() + 1);
            }
        }

        // ── 2. PAUSES D'INACTIVITÉ ────────────────────────────────────────
        if (!pauseDurations.isEmpty()) {
            long longPauses  = pauseDurations.stream().filter(p -> p > 15_000).count();
            long shortPauses = pauseDurations.stream().filter(p -> p < 8_000).count();

            if (longPauses >= 3) {
                // Beaucoup de longues pauses → hésitation, inconfort
                profile.setAnxiety(profile.getAnxiety() + 4);
                profile.setFocus(profile.getFocus() - 2);
                profile.setMood(profile.getMood() - 1);
            } else if (shortPauses > (pauseDurations.size() * 0.7)) {
                // Pauses courtes fréquentes → pensée réflexive naturelle
                profile.setResilience(profile.getResilience() + 3);
                profile.setMood(profile.getMood() + 1);
            }
        } else if (actionCount > 10) {
            // Beaucoup d'actions sans aucune pause → très fluide
            profile.setMood(profile.getMood() + 2);
        }

        // ── 3. RYTHME DE CLICS ───────────────────────────────────────────
        long sessionMinutes = Math.max(1, (System.currentTimeMillis() - sessionStart) / 60_000);
        double clicksPerMin = (double) clickCount / sessionMinutes;

        if (clicksPerMin > 25) {
            profile.setSociability(profile.getSociability() + 4);
            profile.setFocus(profile.getFocus() - 3);
            profile.setAnxiety(profile.getAnxiety() + 1);
        } else if (clicksPerMin > 12) {
            profile.setSociability(profile.getSociability() + 2);
        } else if (clicksPerMin < 2) {
            profile.setFocus(profile.getFocus() + 3);
            profile.setResilience(profile.getResilience() + 2);
        } else if (clicksPerMin < 6) {
            profile.setFocus(profile.getFocus() + 1);
            profile.setResilience(profile.getResilience() + 1);
        }

        // ── 4. PATTERN DE NAVIGATION ─────────────────────────────────────
        if (navSequence.size() >= 2) {
            long allerRetours = countBackAndForth(navSequence);
            if (allerRetours > 3) {
                profile.setAnxiety(profile.getAnxiety() + 3);
                profile.setFocus(profile.getFocus() - 2);
            } else if (allerRetours == 0 && navSequence.size() >= 3) {
                profile.setFocus(profile.getFocus() + 2);
                profile.setResilience(profile.getResilience() + 1);
            }

            long introspect = navSequence.stream()
                .filter(s -> s.contains("psych") || s.contains("mindbot"))
                .count();
            if (introspect >= 2) {
                profile.setResilience(profile.getResilience() + 3);
                profile.setMood(profile.getMood() + 1);
            }
        }

        // ── 5. DURÉE DE SESSION ──────────────────────────────────────────
        long sessionSec = (System.currentTimeMillis() - sessionStart) / 1000;
        if (sessionSec > 300 && actionCount > 15) {
            profile.setMood(profile.getMood() + 2);
            profile.setResilience(profile.getResilience() + 1);
        } else if (sessionSec < 60 && actionCount < 5) {
            profile.setMood(profile.getMood() - 1);
        }

        // ── Recalcule type et anomalie ───────────────────────────────────
        profile.recalculateType();
        profile.recalculateAnomaly();

        // ── Sauvegarde état courant + snapshot historique ─────────────────
        psychDAO.save(profile);
        psychDAO.saveHistory(profile); // Pour le graphique d'évolution

        System.out.printf(
            "📊 [Session %s] anxiety=%.0f resilience=%.0f sociability=%.0f focus=%.0f mood=%.0f → %s (anomalie=%.0f)%n",
            sessionId, profile.getAnxiety(), profile.getResilience(),
            profile.getSociability(), profile.getFocus(), profile.getMood(),
            profile.getDetectedType(), profile.getAnomalyScore()
        );

        // Reset des buffers
        typingIntervals.clear();
        pauseDurations.clear();
        navSequence.clear();
        clickCount  = 0;
        actionCount = 0;
        sessionStart   = System.currentTimeMillis();
        lastActionTime = sessionStart;

        return profile;
    }

    // ── Utilitaires ───────────────────────────────────────────────────────

    private long countBackAndForth(List<String> nav) {
        long count = 0;
        for (int i = 2; i < nav.size(); i++) {
            if (nav.get(i).equals(nav.get(i - 2)) && !nav.get(i).equals(nav.get(i - 1))) {
                count++;
            }
        }
        return count;
    }

    private double standardDeviation(List<Long> values) {
        if (values.size() < 2) return 0;
        double mean = values.stream().mapToLong(Long::longValue).average().orElse(0);
        double variance = values.stream()
            .mapToDouble(v -> (v - mean) * (v - mean))
            .average().orElse(0);
        return Math.sqrt(variance);
    }

    public int    getUserId()    { return userId; }
    public String getSessionId() { return sessionId; }
    public int    getActionCount() { return actionCount; }
}
