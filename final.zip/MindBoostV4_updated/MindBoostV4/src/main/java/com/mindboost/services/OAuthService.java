package com.mindboost.services;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import okhttp3.*;

import java.awt.Desktop;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.*;
import java.util.concurrent.TimeUnit;

/**
 * Service OAuth 2.0 pour GitHub et Google
 *
 * ── GitHub OAuth (gratuit) ──────────────────────────────────────────
 *  1. github.com → Settings → Developer settings → OAuth Apps → New
 *  2. Homepage URL: http://localhost
 *  3. Callback URL: http://localhost:8765/callback
 *  4. Copier Client ID + Client Secret dans config.properties
 *
 * ── Google OAuth (gratuit) ──────────────────────────────────────────
 *  1. console.cloud.google.com → APIs & Services → Credentials
 *  2. Create Credentials → OAuth 2.0 Client IDs → Desktop app
 *  3. Authorized redirect URI: http://localhost:8765/callback
 *  4. Copier Client ID + Client Secret dans config.properties
 */
public class OAuthService {

    // ── GitHub ──
    private static String GITHUB_CLIENT_ID     = System.getProperty("GITHUB_CLIENT_ID", "");
    private static String GITHUB_CLIENT_SECRET = System.getProperty("GITHUB_CLIENT_SECRET", "");
    private static final String GITHUB_AUTH_URL   = "https://github.com/login/oauth/authorize";
    private static final String GITHUB_TOKEN_URL  = "https://github.com/login/oauth/access_token";
    private static final String GITHUB_USER_URL   = "https://api.github.com/user";
    private static final String GITHUB_EMAIL_URL  = "https://api.github.com/user/emails";

    // ── Google ──
    private static String GOOGLE_CLIENT_ID     = System.getProperty("GOOGLE_CLIENT_ID", "");
    private static String GOOGLE_CLIENT_SECRET = System.getProperty("GOOGLE_CLIENT_SECRET", "");
    private static final String GOOGLE_AUTH_URL   = "https://accounts.google.com/o/oauth2/v2/auth";
    private static final String GOOGLE_TOKEN_URL  = "https://oauth2.googleapis.com/token";
    private static final String GOOGLE_USER_URL   = "https://www.googleapis.com/oauth2/v3/userinfo";

    // Callback local
    private static final int    CALLBACK_PORT = 8765;
    private static final String REDIRECT_URI  = "http://localhost:" + CALLBACK_PORT + "/callback";

    private static final OkHttpClient http = new OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build();

    public static void setGithubCredentials(String clientId, String clientSecret) {
        GITHUB_CLIENT_ID     = clientId;
        GITHUB_CLIENT_SECRET = clientSecret;
    }

    public static void setGoogleCredentials(String clientId, String clientSecret) {
        GOOGLE_CLIENT_ID     = clientId;
        GOOGLE_CLIENT_SECRET = clientSecret;
    }

    public static boolean isGithubConfigured() {
        return !GITHUB_CLIENT_ID.isBlank() && !GITHUB_CLIENT_ID.equals("YOUR_GITHUB_CLIENT_ID");
    }

    public static boolean isGoogleConfigured() {
        return !GOOGLE_CLIENT_ID.isBlank() && !GOOGLE_CLIENT_ID.equals("YOUR_GOOGLE_CLIENT_ID");
    }

    // ──────────────────────────────────────────────────────────
    //  GITHUB LOGIN
    // ──────────────────────────────────────────────────────────
    public static OAuthUser loginWithGithub() throws Exception {
        if (!isGithubConfigured()) {
            throw new IllegalStateException(
                "GitHub OAuth non configuré.\n\n"
                + "1. Aller sur github.com → Settings → Developer settings → OAuth Apps\n"
                + "2. New OAuth App\n"
                + "3. Callback URL : http://localhost:8765/callback\n"
                + "4. Ajouter dans config.properties :\n"
                + "   GITHUB_CLIENT_ID=votre_id\n"
                + "   GITHUB_CLIENT_SECRET=votre_secret"
            );
        }

        String state = generateState();
        String authUrl = GITHUB_AUTH_URL
            + "?client_id=" + GITHUB_CLIENT_ID
            + "&redirect_uri=" + URLEncoder.encode(REDIRECT_URI, StandardCharsets.UTF_8)
            + "&scope=user:email"
            + "&state=" + state;

        String code = openBrowserAndWaitForCode(authUrl, state);
        String token = exchangeCodeForToken_Github(code);
        return fetchGithubUser(token);
    }

    // ──────────────────────────────────────────────────────────
    //  GOOGLE LOGIN
    // ──────────────────────────────────────────────────────────
    public static OAuthUser loginWithGoogle() throws Exception {
        if (!isGoogleConfigured()) {
            throw new IllegalStateException(
                "Google OAuth non configuré.\n\n"
                + "1. Aller sur console.cloud.google.com\n"
                + "2. APIs & Services → Credentials → Create OAuth 2.0 Client\n"
                + "3. Type : Desktop App\n"
                + "4. Authorized redirect URI : http://localhost:8765/callback\n"
                + "5. Ajouter dans config.properties :\n"
                + "   GOOGLE_CLIENT_ID=votre_id\n"
                + "   GOOGLE_CLIENT_SECRET=votre_secret"
            );
        }

        String state = generateState();
        String authUrl = GOOGLE_AUTH_URL
            + "?client_id=" + GOOGLE_CLIENT_ID
            + "&redirect_uri=" + URLEncoder.encode(REDIRECT_URI, StandardCharsets.UTF_8)
            + "&response_type=code"
            + "&scope=" + URLEncoder.encode("openid email profile", StandardCharsets.UTF_8)
            + "&state=" + state
            + "&access_type=offline";

        String code = openBrowserAndWaitForCode(authUrl, state);
        String token = exchangeCodeForToken_Google(code);
        return fetchGoogleUser(token);
    }

    // ──────────────────────────────────────────────────────────
    //  Serveur HTTP local pour capturer le code OAuth
    // ──────────────────────────────────────────────────────────
    private static String openBrowserAndWaitForCode(String authUrl, String expectedState) throws Exception {
        CompletableFuture<String> codeFuture = new CompletableFuture<>();

        // Démarrer mini-serveur HTTP
        ServerSocket server = new ServerSocket(CALLBACK_PORT);
        server.setSoTimeout(120_000); // 2 min timeout

        // Ouvrir le navigateur
        if (Desktop.isDesktopSupported()) {
            Desktop.getDesktop().browse(new URI(authUrl));
        } else {
            // Fallback: afficher l'URL
            System.out.println("Ouvrez ce lien dans votre navigateur : " + authUrl);
        }

        // Attendre la requête de callback
        ExecutorService exec = Executors.newSingleThreadExecutor();
        exec.submit(() -> {
            try {
                Socket socket = server.accept();
                BufferedReader reader = new BufferedReader(
                    new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
                String line = reader.readLine();

                // Envoyer réponse HTML
                String html = "<html><body style='font-family:sans-serif;text-align:center;padding:60px'>"
                    + "<h2 style='color:#6C63FF'>✅ Connexion réussie !</h2>"
                    + "<p>Vous pouvez fermer cet onglet et retourner dans MindBoost.</p>"
                    + "</body></html>";
                PrintWriter out = new PrintWriter(socket.getOutputStream());
                out.println("HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nConnection: close\r\n\r\n" + html);
                out.flush();
                socket.close();

                // Extraire le code depuis la requête GET /callback?code=xxx&state=yyy
                if (line != null && line.contains("code=")) {
                    Map<String, String> params = parseQueryString(line);
                    String state = params.get("state");
                    String code  = params.get("code");
                    if (expectedState.equals(state) && code != null) {
                        codeFuture.complete(code);
                    } else {
                        codeFuture.completeExceptionally(new Exception("State OAuth invalide — possible CSRF."));
                    }
                } else {
                    codeFuture.completeExceptionally(new Exception("Aucun code reçu du fournisseur OAuth."));
                }
            } catch (Exception e) {
                codeFuture.completeExceptionally(e);
            } finally {
                try { server.close(); } catch (Exception ignored) {}
            }
        });

        try {
            return codeFuture.get(120, TimeUnit.SECONDS);
        } catch (TimeoutException e) {
            throw new Exception("Timeout : vous n'avez pas autorisé la connexion dans les 2 minutes.");
        } finally {
            exec.shutdown();
        }
    }

    // ──────────────────────────────────────────────────────────
    //  Échange de code → token (GitHub)
    // ──────────────────────────────────────────────────────────
    private static String exchangeCodeForToken_Github(String code) throws IOException {
        RequestBody form = new FormBody.Builder()
            .add("client_id", GITHUB_CLIENT_ID)
            .add("client_secret", GITHUB_CLIENT_SECRET)
            .add("code", code)
            .add("redirect_uri", REDIRECT_URI)
            .build();

        Request request = new Request.Builder()
            .url(GITHUB_TOKEN_URL)
            .addHeader("Accept", "application/json")
            .post(form)
            .build();

        try (Response resp = http.newCall(request).execute()) {
            String body = resp.body().string();
            JsonObject json = JsonParser.parseString(body).getAsJsonObject();
            if (json.has("error")) {
                throw new IOException("GitHub token error: " + json.get("error_description").getAsString());
            }
            return json.get("access_token").getAsString();
        }
    }

    // ──────────────────────────────────────────────────────────
    //  Échange de code → token (Google)
    // ──────────────────────────────────────────────────────────
    private static String exchangeCodeForToken_Google(String code) throws IOException {
        RequestBody form = new FormBody.Builder()
            .add("client_id", GOOGLE_CLIENT_ID)
            .add("client_secret", GOOGLE_CLIENT_SECRET)
            .add("code", code)
            .add("redirect_uri", REDIRECT_URI)
            .add("grant_type", "authorization_code")
            .build();

        Request request = new Request.Builder()
            .url(GOOGLE_TOKEN_URL)
            .post(form)
            .build();

        try (Response resp = http.newCall(request).execute()) {
            String body = resp.body().string();
            JsonObject json = JsonParser.parseString(body).getAsJsonObject();
            if (json.has("error")) {
                throw new IOException("Google token error: " + json.get("error").getAsString());
            }
            return json.get("access_token").getAsString();
        }
    }

    // ──────────────────────────────────────────────────────────
    //  Récupération des infos utilisateur GitHub
    // ──────────────────────────────────────────────────────────
    private static OAuthUser fetchGithubUser(String token) throws IOException {
        Request req = new Request.Builder()
            .url(GITHUB_USER_URL)
            .addHeader("Authorization", "Bearer " + token)
            .addHeader("Accept", "application/vnd.github+json")
            .build();

        try (Response resp = http.newCall(req).execute()) {
            JsonObject user = JsonParser.parseString(resp.body().string()).getAsJsonObject();

            String email = user.has("email") && !user.get("email").isJsonNull()
                ? user.get("email").getAsString() : null;

            // Si email non public → chercher dans /user/emails
            if (email == null || email.isBlank()) {
                email = fetchGithubPrimaryEmail(token);
            }

            String name  = user.has("name") && !user.get("name").isJsonNull()
                ? user.get("name").getAsString()
                : user.get("login").getAsString();

            return new OAuthUser(
                "github",
                String.valueOf(user.get("id").getAsLong()),
                name,
                email != null ? email : user.get("login").getAsString() + "@github.com"
            );
        }
    }

    private static String fetchGithubPrimaryEmail(String token) throws IOException {
        Request req = new Request.Builder()
            .url(GITHUB_EMAIL_URL)
            .addHeader("Authorization", "Bearer " + token)
            .addHeader("Accept", "application/vnd.github+json")
            .build();

        try (Response resp = http.newCall(req).execute()) {
            var arr = JsonParser.parseString(resp.body().string()).getAsJsonArray();
            for (var el : arr) {
                JsonObject e = el.getAsJsonObject();
                if (e.get("primary").getAsBoolean()) return e.get("email").getAsString();
            }
            if (arr.size() > 0) return arr.get(0).getAsJsonObject().get("email").getAsString();
        }
        return null;
    }

    // ──────────────────────────────────────────────────────────
    //  Récupération des infos utilisateur Google
    // ──────────────────────────────────────────────────────────
    private static OAuthUser fetchGoogleUser(String token) throws IOException {
        Request req = new Request.Builder()
            .url(GOOGLE_USER_URL)
            .addHeader("Authorization", "Bearer " + token)
            .build();

        try (Response resp = http.newCall(req).execute()) {
            JsonObject user = JsonParser.parseString(resp.body().string()).getAsJsonObject();
            return new OAuthUser(
                "google",
                user.get("sub").getAsString(),
                user.get("name").getAsString(),
                user.get("email").getAsString()
            );
        }
    }

    // ──────────────────────────────────────────────────────────
    //  Helpers
    // ──────────────────────────────────────────────────────────
    private static String generateState() {
        return Long.toHexString(System.nanoTime()) + Long.toHexString((long)(Math.random() * Long.MAX_VALUE));
    }

    private static Map<String, String> parseQueryString(String requestLine) {
        Map<String, String> params = new HashMap<>();
        try {
            // requestLine = "GET /callback?code=xxx&state=yyy HTTP/1.1"
            int qStart = requestLine.indexOf('?');
            int qEnd   = requestLine.lastIndexOf(' ');
            if (qStart < 0) return params;
            String query = requestLine.substring(qStart + 1, qEnd > qStart ? qEnd : requestLine.length());
            for (String pair : query.split("&")) {
                String[] kv = pair.split("=", 2);
                if (kv.length == 2) {
                    params.put(
                        URLDecoder.decode(kv[0], StandardCharsets.UTF_8),
                        URLDecoder.decode(kv[1], StandardCharsets.UTF_8)
                    );
                }
            }
        } catch (Exception ignored) {}
        return params;
    }

    // ──────────────────────────────────────────────────────────
    //  Data class
    // ──────────────────────────────────────────────────────────
    public static class OAuthUser {
        public final String provider; // "github" | "google"
        public final String providerId;
        public final String name;
        public final String email;

        public OAuthUser(String provider, String providerId, String name, String email) {
            this.provider   = provider;
            this.providerId = providerId;
            this.name       = name;
            this.email      = email;
        }
    }
}
