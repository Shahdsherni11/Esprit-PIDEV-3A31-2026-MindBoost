package com.mindboost.utils;

import com.mindboost.services.BrevoEmailService;
import com.mindboost.services.GroqAIService;
import com.mindboost.services.OAuthService;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/**
 * Charge la configuration depuis config.properties.
 * Priorité : variable d'environnement > config.properties
 */
public class ConfigLoader {

    private static Properties props;

    public static void load() {
        props = new Properties();
        try (InputStream is = ConfigLoader.class.getResourceAsStream("/config.properties")) {
            if (is != null) {
                props.load(is);

                // ── Groq AI ─────────────────────────────
                String groqKey = get("GROQ_API_KEY");
                if (groqKey != null && !groqKey.isBlank() && !groqKey.equals("YOUR_GROQ_KEY_HERE")) {
                    GroqAIService.setApiKey(groqKey);
                    System.out.println("✅ Clé Groq chargée — MindBot actif");
                } else {
                    System.out.println("⚠️ Groq non configuré — Ollama local sera tenté en premier");
                }

                // ── OAuth GitHub ─────────────────────────
                String ghId     = get("GITHUB_CLIENT_ID");
                String ghSecret = get("GITHUB_CLIENT_SECRET");
                if (isValid(ghId, "YOUR_GITHUB_CLIENT_ID") && isValid(ghSecret, "YOUR_GITHUB_CLIENT_SECRET")) {
                    OAuthService.setGithubCredentials(ghId, ghSecret);
                    System.out.println("✅ OAuth GitHub configuré");
                } else {
                    System.out.println("⚠️ OAuth GitHub non configuré (bouton désactivé)");
                }

                // ── OAuth Google ─────────────────────────
                String ggId     = get("GOOGLE_CLIENT_ID");
                String ggSecret = get("GOOGLE_CLIENT_SECRET");
                if (isValid(ggId, "YOUR_GOOGLE_CLIENT_ID") && isValid(ggSecret, "YOUR_GOOGLE_CLIENT_SECRET")) {
                    OAuthService.setGoogleCredentials(ggId, ggSecret);
                    System.out.println("✅ OAuth Google configuré");
                } else {
                    System.out.println("⚠️ OAuth Google non configuré (bouton désactivé)");
                }

                // ── Brevo Email ──────────────────────────
                String brevoKey = get("BREVO_API_KEY");
                if (isValid(brevoKey, "YOUR_KEY_HERE")) {
                    BrevoEmailService.setApiKey(brevoKey);
                    System.out.println("✅ Clé Brevo chargée");
                } else {
                    System.out.println("⚠️ Clé Brevo non configurée");
                }

            } else {
                System.out.println("⚠️ config.properties introuvable dans le classpath");
            }
        } catch (IOException e) {
            System.err.println("⚠️ Erreur lecture config.properties: " + e.getMessage());
        }
    }

    public static String get(String key) {
        if (key == null) return null;
        String envVal = System.getenv(key);
        if (envVal != null && !envVal.isBlank()) return envVal;
        return props != null ? props.getProperty(key) : null;
    }

    private static boolean isValid(String value, String placeholder) {
        return value != null && !value.isBlank() && !value.equals(placeholder);
    }
}
