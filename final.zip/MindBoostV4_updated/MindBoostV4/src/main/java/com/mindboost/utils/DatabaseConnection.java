package com.mindboost.utils;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DatabaseConnection {

    private static DatabaseConnection instance;
    private Connection connection;

    // Defaults (overridden by config.properties or env vars)
    private static String DB_URL      = "jdbc:mysql://localhost:3306/mindboost_db?serverTimezone=UTC&useSSL=false&allowPublicKeyRetrieval=true";
    private static String DB_USER     = "root";
    private static String DB_PASSWORD = "";

    static {
        // Load DB config from config.properties
        try (InputStream is = DatabaseConnection.class.getResourceAsStream("/config.properties")) {
            if (is != null) {
                Properties props = new Properties();
                props.load(is);
                String url  = props.getProperty("DB_URL");
                String user = props.getProperty("DB_USER");
                String pass = props.getProperty("DB_PASSWORD");
                if (url  != null && !url.isBlank())  DB_URL      = url;
                if (user != null && !user.isBlank()) DB_USER     = user;
                if (pass != null)                    DB_PASSWORD  = pass;
            }
        } catch (IOException ignored) {}

        // Environment variables override config.properties
        String envUrl  = System.getenv("DB_URL");
        String envUser = System.getenv("DB_USER");
        String envPass = System.getenv("DB_PASSWORD");
        if (envUrl  != null) DB_URL      = envUrl;
        if (envUser != null) DB_USER     = envUser;
        if (envPass != null) DB_PASSWORD = envPass;
    }

    private DatabaseConnection() {
        connect();
    }

    private void connect() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            this.connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            System.out.println("✅ Database connected: " + DB_URL);
        } catch (Exception e) {
            System.err.println("❌ Cannot connect to database: " + e.getMessage());
            throw new RuntimeException("Cannot connect to database: " + e.getMessage(), e);
        }
    }

    public static synchronized DatabaseConnection getInstance() {
        if (instance == null) {
            instance = new DatabaseConnection();
        } else {
            try {
                if (instance.connection == null || instance.connection.isClosed()
                        || !instance.connection.isValid(5)) {
                    System.out.println("⚠️ DB connection lost — reconnecting...");
                    instance.connect();
                }
            } catch (SQLException e) {
                System.out.println("⚠️ DB connection check failed — reconnecting...");
                instance.connect();
            }
        }
        return instance;
    }

    public Connection getConnection() {
        return connection;
    }
}
