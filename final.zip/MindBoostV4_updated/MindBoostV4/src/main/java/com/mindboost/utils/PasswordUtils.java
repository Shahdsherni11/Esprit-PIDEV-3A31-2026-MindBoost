package com.mindboost.utils;

import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;

public class PasswordUtils {

    private static final SecureRandom RANDOM = new SecureRandom();

    /**
     * Hash un mot de passe avec SHA-256 + sel aléatoire.
     * Format retourné : "BASE64_SALT:BASE64_HASH"
     */
    public static String hashPassword(String password) {
        try {
            byte[] salt = new byte[16];
            RANDOM.nextBytes(salt);
            byte[] hash = sha256(salt, password);
            return Base64.getEncoder().encodeToString(salt)
                   + ":" + Base64.getEncoder().encodeToString(hash);
        } catch (Exception e) {
            throw new RuntimeException("Erreur de hachage", e);
        }
    }

    /**
     * Vérifie un mot de passe.
     * Supporte le format SHA-256 du projet ("salt:hash").
     * Supporte aussi les mots de passe en clair stockés (migration initiale).
     */
    public static boolean verifyPassword(String password, String stored) {
        if (stored == null || password == null) return false;

        // Format SHA-256 : "BASE64_SALT:BASE64_HASH"
        if (stored.contains(":")) {
            try {
                String[] parts = stored.split(":", 2);
                if (parts.length != 2) return false;
                byte[] salt = Base64.getDecoder().decode(parts[0]);
                byte[] expectedHash = Base64.getDecoder().decode(parts[1]);
                byte[] actualHash   = sha256(salt, password);
                return MessageDigest.isEqual(expectedHash, actualHash);
            } catch (Exception e) {
                return false;
            }
        }

        // Fallback : mot de passe en clair (pour comptes de test/migration)
        return stored.equals(password);
    }

    private static byte[] sha256(byte[] salt, String password) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        md.update(salt);
        return md.digest(password.getBytes("UTF-8"));
    }
}
