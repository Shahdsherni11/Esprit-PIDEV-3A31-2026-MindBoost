package com.mindboost.controllers;

import com.mindboost.dao.BehaviorDAO;
import com.mindboost.dao.PsychProfileDAO;
import com.mindboost.dao.UserDAO;
import com.mindboost.models.PsychProfile;
import com.mindboost.models.User;
import com.mindboost.services.AdaptiveUIService;
import com.mindboost.services.BrevoEmailService;
import com.mindboost.utils.SessionManager;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.canvas.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.*;
import javafx.scene.text.Font;

import java.time.format.DateTimeFormatter;
import java.util.List;

public class PsychMapController {

    @FXML private Canvas  radarCanvas;
    @FXML private Label   typeLabel;
    @FXML private Label   anomalyLabel;
    @FXML private Label   lastUpdatedLabel;
    @FXML private ProgressBar anxietyBar;
    @FXML private ProgressBar resilienceBar;
    @FXML private ProgressBar sociabilityBar;
    @FXML private ProgressBar focusBar;
    @FXML private ProgressBar moodBar;
    @FXML private Label   anxietyPct;
    @FXML private Label   resiliencePct;
    @FXML private Label   sociabilityPct;
    @FXML private Label   focusPct;
    @FXML private Label   moodPct;
    @FXML private VBox    alertBox;
    @FXML private Label   alertLabel;
    @FXML private Button  sendAlertBtn;
    @FXML private ComboBox<String> psyEmailCombo;
    @FXML private Label   themeLabel;
    @FXML private Canvas  historyCanvas;  // Graphique d'évolution (peut être null si absent du FXML)

    private final PsychProfileDAO psychDAO = new PsychProfileDAO();
    private final UserDAO         userDAO  = new UserDAO();
    private PsychProfile          profile;

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd/MM HH:mm");

    @FXML
    public void initialize() {
        User user = SessionManager.getInstance().getCurrentUser();
        if (user == null) return;

        try {
            profile = psychDAO.getByUserId(user.getId());
            if (profile == null) {
                profile = new PsychProfile(user.getId());
                psychDAO.save(profile);
            }
            updateUI();
            drawRadarChart();
            drawHistoryChart(user.getId());
            loadPsychologists();
            checkAnomalyAlert();
        } catch (Exception e) {
            e.printStackTrace();
            profile = new PsychProfile(user.getId());
            updateUI();
            drawRadarChart();
        }
    }

    // ── Mise à jour de l'UI ───────────────────────────────────────────────

    private void updateUI() {
        if (profile == null) return;

        if (typeLabel != null) {
            typeLabel.setText(getTypeEmoji(profile.getDetectedType()) + " " + profile.getDetectedType());
            typeLabel.setStyle("-fx-text-fill:#6C63FF;-fx-font-size:20px;-fx-font-weight:bold;");
        }

        double anomaly = profile.getAnomalyScore();
        if (anomalyLabel != null) {
            anomalyLabel.setText(String.format("Score d'anomalie: %.0f%%", anomaly));
            String color = anomaly >= 70 ? "#E74C3C" : anomaly >= 50 ? "#F39C12" : "#2ECC71";
            anomalyLabel.setStyle("-fx-text-fill:" + color + ";-fx-font-size:14px;");
        }

        setBar(anxietyBar,     anxietyPct,     profile.getAnxiety(),     "#E74C3C");
        setBar(resilienceBar,  resiliencePct,  profile.getResilience(),  "#2ECC71");
        setBar(sociabilityBar, sociabilityPct, profile.getSociability(), "#4ECDC4");
        setBar(focusBar,       focusPct,       profile.getFocus(),       "#6C63FF");
        setBar(moodBar,        moodPct,        profile.getMood(),        "#F39C12");

        if (themeLabel != null) {
            AdaptiveUIService.UITheme theme = AdaptiveUIService.determineTheme(profile);
            themeLabel.setText("🔮 Thème : " + theme.name());
        }

        if (lastUpdatedLabel != null && profile.getLastUpdated() != null) {
            lastUpdatedLabel.setText("Dernière analyse : "
                + profile.getLastUpdated().format(DateTimeFormatter.ofPattern("dd/MM/yyyy à HH:mm")));
        } else if (lastUpdatedLabel != null) {
            lastUpdatedLabel.setText("Pas encore analysé — Utilisez l'app pour générer des données");
        }
    }

    private void setBar(ProgressBar bar, Label pct, double value, String color) {
        if (bar != null) { bar.setProgress(value / 100.0); bar.setStyle("-fx-accent:" + color + ";"); }
        if (pct != null) {
            pct.setText((int) value + "%");
            pct.setStyle("-fx-text-fill:" + color + ";-fx-font-weight:bold;");
        }
    }

    // ── Radar Chart ───────────────────────────────────────────────────────

    private void drawRadarChart() {
        if (radarCanvas == null || profile == null) return;
        GraphicsContext gc = radarCanvas.getGraphicsContext2D();
        double w  = radarCanvas.getWidth();
        double h  = radarCanvas.getHeight();
        double cx = w / 2, cy = h / 2;
        double maxR = Math.min(w, h) / 2 - 35;

        gc.clearRect(0, 0, w, h);

        // Grilles de fond
        for (int level = 1; level <= 4; level++) {
            double r = maxR * level / 4.0;
            gc.setStroke(Color.web("rgba(255,255,255,0.07)"));
            gc.setLineWidth(1);
            drawPolygon(gc, cx, cy, r, 5, -Math.PI / 2);
        }

        String[] labels = {"😰 Anxiété", "💪 Résilience", "💬 Social", "🎯 Focus", "😊 Humeur"};
        double[] values = {
            profile.getAnxiety(), profile.getResilience(),
            profile.getSociability(), profile.getFocus(), profile.getMood()
        };
        String[] colors = {"#E74C3C", "#2ECC71", "#4ECDC4", "#6C63FF", "#F39C12"};

        // Axes + labels
        for (int i = 0; i < 5; i++) {
            double angle = -Math.PI / 2 + i * 2 * Math.PI / 5;
            gc.setStroke(Color.web("rgba(255,255,255,0.12)"));
            gc.strokeLine(cx, cy, cx + maxR * Math.cos(angle), cy + maxR * Math.sin(angle));
            double lx = cx + (maxR + 26) * Math.cos(angle);
            double ly = cy + (maxR + 26) * Math.sin(angle);
            gc.setFill(Color.web(colors[i]));
            gc.setFont(Font.font("Segoe UI", 11));
            gc.fillText(labels[i], lx - 30, ly + 4);
        }

        // Polygone des scores
        double[] px = new double[5], py = new double[5];
        for (int i = 0; i < 5; i++) {
            double angle = -Math.PI / 2 + i * 2 * Math.PI / 5;
            double r = maxR * values[i] / 100.0;
            px[i] = cx + r * Math.cos(angle);
            py[i] = cy + r * Math.sin(angle);
        }
        gc.setFill(Color.web("rgba(108,99,255,0.22)"));
        gc.fillPolygon(px, py, 5);
        gc.setStroke(Color.web("#6C63FF"));
        gc.setLineWidth(2.5);
        gc.strokePolygon(px, py, 5);

        // Points sur les sommets
        for (int i = 0; i < 5; i++) {
            gc.setFill(Color.web(colors[i]));
            gc.fillOval(px[i] - 5, py[i] - 5, 10, 10);
            gc.setFill(Color.WHITE);
            gc.setFont(Font.font(9));
            gc.fillText((int)values[i] + "%", px[i] - 10, py[i] - 8);
        }
    }

    // ── Graphique d'évolution temporelle ─────────────────────────────────

    /**
     * Dessine un graphique linéaire montrant l'évolution des 5 dimensions
     * dans le temps, basé sur les snapshots sauvegardés dans psych_profile_history.
     */
    private void drawHistoryChart(int userId) {
        if (historyCanvas == null) return; // canvas optionnel dans le FXML

        List<PsychProfile> history;
        try {
            history = psychDAO.getHistory(userId, 10); // 10 derniers snapshots
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }

        if (history.size() < 2) {
            // Pas assez de données : affiche un message
            GraphicsContext gc = historyCanvas.getGraphicsContext2D();
            gc.clearRect(0, 0, historyCanvas.getWidth(), historyCanvas.getHeight());
            gc.setFill(Color.web("#9B9BB0"));
            gc.setFont(Font.font("Segoe UI", 13));
            gc.fillText("📊 Graphique d'évolution disponible après 2+ sessions d'utilisation", 20, 80);
            gc.fillText("Continuez à utiliser MindBoost pour voir vos tendances.", 20, 105);
            return;
        }

        // Les snapshots sont en ordre DESC (plus récent en premier), on inverse
        java.util.Collections.reverse(history);

        GraphicsContext gc = historyCanvas.getGraphicsContext2D();
        double w  = historyCanvas.getWidth();
        double h  = historyCanvas.getHeight();
        double padL = 40, padR = 20, padT = 20, padB = 40;
        double chartW = w - padL - padR;
        double chartH = h - padT - padB;

        gc.clearRect(0, 0, w, h);

        // Fond
        gc.setFill(Color.web("rgba(255,255,255,0.03)"));
        gc.fillRoundRect(padL, padT, chartW, chartH, 8, 8);

        // Axes
        gc.setStroke(Color.web("rgba(255,255,255,0.15)"));
        gc.setLineWidth(1);
        gc.strokeLine(padL, padT, padL, padT + chartH);
        gc.strokeLine(padL, padT + chartH, padL + chartW, padT + chartH);

        // Lignes horizontales (0, 25, 50, 75, 100)
        for (int v : new int[]{0, 25, 50, 75, 100}) {
            double y = padT + chartH - (v / 100.0) * chartH;
            gc.setStroke(Color.web("rgba(255,255,255,0.06)"));
            gc.strokeLine(padL, y, padL + chartW, y);
            gc.setFill(Color.web("#6B6B80"));
            gc.setFont(Font.font(9));
            gc.fillText(v + "", padL - 26, y + 4);
        }

        // Axe X : dates
        int n = history.size();
        for (int i = 0; i < n; i++) {
            double x = padL + (i / (double)(n - 1)) * chartW;
            gc.setFill(Color.web("#6B6B80"));
            gc.setFont(Font.font(8));
            String dateStr = history.get(i).getLastUpdated() != null
                ? history.get(i).getLastUpdated().format(FMT) : "s" + (i+1);
            gc.fillText(dateStr, x - 15, padT + chartH + 14);
        }

        // Courbes des 5 dimensions
        String[] dimNames  = {"Anxiété", "Résilience", "Sociabilité", "Focus", "Humeur"};
        String[] dimColors = {"#E74C3C", "#2ECC71", "#4ECDC4", "#6C63FF", "#F39C12"};

        for (int d = 0; d < 5; d++) {
            gc.setStroke(Color.web(dimColors[d]));
            gc.setLineWidth(2.0);
            gc.beginPath();

            for (int i = 0; i < n; i++) {
                double val = getDim(history.get(i), d);
                double x = padL + (i / (double)(n - 1)) * chartW;
                double y = padT + chartH - (val / 100.0) * chartH;
                if (i == 0) gc.moveTo(x, y); else gc.lineTo(x, y);
            }
            gc.stroke();

            // Point sur le dernier snapshot
            double lastVal = getDim(history.get(n - 1), d);
            double lx = padL + chartW;
            double ly = padT + chartH - (lastVal / 100.0) * chartH;
            gc.setFill(Color.web(dimColors[d]));
            gc.fillOval(lx - 4, ly - 4, 8, 8);
        }

        // Légende
        for (int d = 0; d < 5; d++) {
            double legX = padL + d * (chartW / 5.0);
            gc.setFill(Color.web(dimColors[d]));
            gc.fillRect(legX, h - 12, 12, 4);
            gc.setFont(Font.font(9));
            gc.fillText(dimNames[d], legX + 15, h - 8);
        }
    }

    private double getDim(PsychProfile p, int d) {
        return switch (d) {
            case 0 -> p.getAnxiety();
            case 1 -> p.getResilience();
            case 2 -> p.getSociability();
            case 3 -> p.getFocus();
            case 4 -> p.getMood();
            default -> 50;
        };
    }

    private void drawPolygon(GraphicsContext gc, double cx, double cy,
                              double r, int sides, double startAngle) {
        double[] x = new double[sides], y = new double[sides];
        for (int i = 0; i < sides; i++) {
            double a = startAngle + i * 2 * Math.PI / sides;
            x[i] = cx + r * Math.cos(a);
            y[i] = cy + r * Math.sin(a);
        }
        gc.strokePolygon(x, y, sides);
    }

    // ── Alerte anomalie ───────────────────────────────────────────────────

    private void checkAnomalyAlert() {
        if (profile == null || alertBox == null) return;
        String alertMsg = profile.getAlertMessage();
        alertBox.setVisible(alertMsg != null);
        if (alertMsg != null && alertLabel != null) alertLabel.setText(alertMsg);
    }

    private void loadPsychologists() {
        if (psyEmailCombo == null) return;
        try {
            userDAO.getAllUsers().stream()
                .filter(u -> "psychologist".equals(u.getRole()))
                .forEach(u -> psyEmailCombo.getItems().add(u.getEmail()));
            if (!psyEmailCombo.getItems().isEmpty())
                psyEmailCombo.setValue(psyEmailCombo.getItems().get(0));
            else
                psyEmailCombo.setPromptText("Aucun psychologue disponible");
        } catch (Exception e) { e.printStackTrace(); }
    }

    @FXML
    public void handleSendAlert() {
        String psyEmail = psyEmailCombo != null ? psyEmailCombo.getValue() : null;
        if (psyEmail == null || psyEmail.isBlank()) { showInfo("❌ Aucun psychologue sélectionné."); return; }

        User user        = SessionManager.getInstance().getCurrentUser();
        String patient   = user != null ? user.getEmail() : "Patient";
        String alertMsg  = profile != null && profile.getAlertMessage() != null ? profile.getAlertMessage() : "Alerte manuelle.";
        double score     = profile != null ? profile.getAnomalyScore() : 0;

        if (sendAlertBtn != null) { sendAlertBtn.setDisable(true); sendAlertBtn.setText("⏳ Envoi..."); }

        new Thread(() -> {
            try {
                boolean sent = BrevoEmailService.sendPsychAlert(psyEmail, "Dr. Psychologue", patient, alertMsg, score);
                Platform.runLater(() -> {
                    if (sendAlertBtn == null) return;
                    if (sent) { sendAlertBtn.setText("✅ Alerte envoyée !"); sendAlertBtn.setStyle("-fx-background-color:#2ECC71;"); }
                    else      { sendAlertBtn.setText("⚠️ Vérifiez la clé Brevo"); sendAlertBtn.setDisable(false); }
                });
            } catch (Exception e) {
                Platform.runLater(() -> { if (sendAlertBtn != null) { sendAlertBtn.setText("❌ Erreur"); sendAlertBtn.setDisable(false); } });
            }
        }).start();
    }

    @FXML
    public void handleRefresh() {
        User user = SessionManager.getInstance().getCurrentUser();
        if (user == null) return;
        try {
            profile = psychDAO.getByUserId(user.getId());
            if (profile == null) profile = new PsychProfile(user.getId());
            updateUI();
            drawRadarChart();
            drawHistoryChart(user.getId());
            checkAnomalyAlert();
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void showInfo(String msg) { new Alert(Alert.AlertType.INFORMATION, msg).showAndWait(); }

    private String getTypeEmoji(String type) {
        if (type == null) return "🧠";
        return switch (type) {
            case "ANALYTIQUE" -> "🔬";
            case "CREATIF"    -> "🎨";
            case "SOCIAL"     -> "💬";
            case "EMPATHIQUE" -> "💙";
            case "LEADER"     -> "👑";
            default           -> "🧠";
        };
    }
}
