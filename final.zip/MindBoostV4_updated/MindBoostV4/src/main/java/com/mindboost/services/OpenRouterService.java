package com.mindboost.services;

import com.google.gson.*;
import okhttp3.*;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Service MindBot — OpenRouter (gratuit avec clé API)
 * Modèle: google/gemma-3-4b-it:free  → Gratuit et actif en 2025
 *
 * Obtenir une clé gratuite : https://openrouter.ai  (pas de CB requise)
 * Autres modèles gratuits disponibles : meta-llama/llama-3.2-3b-instruct:free
 */
public class OpenRouterService {

    private static String API_KEY = System.getProperty("OPENROUTER_API_KEY", "YOUR_KEY_HERE");
    private static final String API_URL = "https://openrouter.ai/api/v1/chat/completions";

    // ✅ Modèle gratuit actif sur OpenRouter en 2025
    // Alternatives gratuites si celui-ci est indisponible :
    //   "meta-llama/llama-3.2-3b-instruct:free"
    //   "microsoft/phi-3-mini-128k-instruct:free"
    //   "google/gemma-3-1b-it:free"
    private static final String MODEL = "google/gemma-3-4b-it:free";

    private static final OkHttpClient client = new OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build();

    public static void setApiKey(String key) {
        API_KEY = key;
    }

    public static String chat(String userMessage, String psychContext,
                              List<Map<String, String>> history) throws IOException {

        // Clé API non configurée → message clair
        if (API_KEY == null || API_KEY.isBlank()
                || API_KEY.equals("YOUR_KEY_HERE")
                || API_KEY.equals("YOUR_OPENROUTER_KEY")) {
            return "🔑 MindBot n'est pas encore configuré.\n\n"
                + "Pour l'activer :\n"
                + "1. Créez un compte gratuit sur openrouter.ai\n"
                + "2. Copiez votre clé API (sk-or-...)\n"
                + "3. Collez-la dans config.properties → OPENROUTER_API_KEY=sk-or-...\n"
                + "4. Relancez l'application\n\n"
                + "C'est gratuit, sans carte bancaire !";
        }

        JsonObject body = new JsonObject();
        body.addProperty("model", MODEL);

        JsonArray messages = new JsonArray();

        // Prompt système avec contexte psychologique
        JsonObject system = new JsonObject();
        system.addProperty("role", "system");
        system.addProperty("content",
            "Tu es MindBot, un assistant psychologique bienveillant et empathique de la plateforme MindBoost. "
            + "Tu parles TOUJOURS en français. Tu adaptes ton ton selon le profil de l'utilisateur. "
            + "Contexte psychologique actuel: " + (psychContext != null ? psychContext : "Non disponible") + ". "
            + "Réponds avec empathie, de façon concise (max 120 mots), propose des exercices pratiques si pertinent. "
            + "Ne diagnostique JAMAIS, oriente vers un professionnel si nécessaire. "
            + "Réponds uniquement en français, jamais en anglais.");
        messages.add(system);

        // Historique limité aux 8 derniers échanges
        int start = Math.max(0, history.size() - 8);
        for (int i = start; i < history.size(); i++) {
            Map<String, String> msg = history.get(i);
            if (msg.get("role") == null || msg.get("content") == null) continue;
            JsonObject m = new JsonObject();
            m.addProperty("role", msg.get("role"));
            m.addProperty("content", msg.get("content"));
            messages.add(m);
        }

        // Message utilisateur actuel
        JsonObject userMsg = new JsonObject();
        userMsg.addProperty("role", "user");
        userMsg.addProperty("content", userMessage);
        messages.add(userMsg);

        body.add("messages", messages);
        body.addProperty("max_tokens", 250);
        body.addProperty("temperature", 0.7);
        body.addProperty("top_p", 0.9);

        Request request = new Request.Builder()
            .url(API_URL)
            .addHeader("Authorization", "Bearer " + API_KEY)
            .addHeader("HTTP-Referer", "https://mindboost.app")
            .addHeader("X-Title", "MindBoost")
            .addHeader("Content-Type", "application/json")
            .post(RequestBody.create(body.toString(), MediaType.get("application/json")))
            .build();

        try (Response response = client.newCall(request).execute()) {
            ResponseBody responseBody = response.body();

            // Erreur HTTP
            if (!response.isSuccessful() || responseBody == null) {
                int code = response.code();
                if (code == 401) return "❌ Clé API invalide. Vérifiez OPENROUTER_API_KEY dans config.properties.";
                if (code == 429) return "⏳ Limite de requêtes atteinte. Attendez quelques secondes et réessayez.";
                if (code == 402) return "💳 Quota gratuit dépassé. Créez un nouveau compte OpenRouter ou attendez demain.";
                return "⚠️ MindBot indisponible (HTTP " + code + "). Réessayez dans un instant.";
            }

            String respBody = responseBody.string();

            try {
                JsonObject json = JsonParser.parseString(respBody).getAsJsonObject();

                // Erreur retournée par l'API
                if (json.has("error")) {
                    JsonElement errEl = json.get("error");
                    String errMsg = errEl.isJsonObject()
                        ? errEl.getAsJsonObject().get("message").getAsString()
                        : errEl.getAsString();
                    // Modèle indisponible → suggère alternative
                    if (errMsg.contains("model") || errMsg.contains("404")) {
                        return "⚠️ Le modèle IA est temporairement indisponible.\n"
                            + "Changez MODEL dans OpenRouterService.java par :\n"
                            + "\"meta-llama/llama-3.2-3b-instruct:free\"";
                    }
                    return "⚠️ Erreur API: " + errMsg;
                }

                JsonArray choices = json.getAsJsonArray("choices");
                if (choices == null || choices.size() == 0) {
                    return "⚠️ Aucune réponse reçue. Réessayez dans un instant.";
                }

                String content = choices.get(0).getAsJsonObject()
                    .getAsJsonObject("message")
                    .get("content").getAsString().trim();

                return content.isEmpty()
                    ? "Je suis là pour vous aider. Pouvez-vous reformuler votre question ?"
                    : content;

            } catch (JsonParseException | IllegalStateException | NullPointerException e) {
                System.err.println("❌ OpenRouter parse error: " + e.getMessage());
                System.err.println("Raw response: " + respBody.substring(0, Math.min(200, respBody.length())));
                return "⚠️ Réponse inattendue du serveur. Réessayez dans un instant.";
            }
        }
    }
}
