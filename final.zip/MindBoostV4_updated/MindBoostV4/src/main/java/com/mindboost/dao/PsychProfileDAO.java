package com.mindboost.dao;

import com.mindboost.models.PsychProfile;
import com.mindboost.utils.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PsychProfileDAO {

    private Connection conn() { return DatabaseConnection.getInstance().getConnection(); }

    // ── Lecture ──────────────────────────────────────────────────────────

    public PsychProfile getByUserId(int userId) throws SQLException {
        String sql = "SELECT * FROM psych_profile WHERE user_id=?";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return map(rs);
        }
        return null;
    }

    // ── Sauvegarde (état courant) ─────────────────────────────────────────

    public boolean save(PsychProfile p) throws SQLException {
        String sql = "INSERT INTO psych_profile (user_id,anxiety,resilience,sociability,focus,mood,anomaly_score,detected_type) "
                   + "VALUES (?,?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE "
                   + "anxiety=VALUES(anxiety), resilience=VALUES(resilience), sociability=VALUES(sociability), "
                   + "focus=VALUES(focus), mood=VALUES(mood), anomaly_score=VALUES(anomaly_score), "
                   + "detected_type=VALUES(detected_type)";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setInt(1, p.getUserId());
            ps.setDouble(2, p.getAnxiety());
            ps.setDouble(3, p.getResilience());
            ps.setDouble(4, p.getSociability());
            ps.setDouble(5, p.getFocus());
            ps.setDouble(6, p.getMood());
            ps.setDouble(7, p.getAnomalyScore());
            ps.setString(8, p.getDetectedType());
            return ps.executeUpdate() > 0;
        }
    }

    // ── Sauvegarde dans l'historique (snapshot daté) ──────────────────────

    /**
     * Enregistre un snapshot du profil dans l'historique.
     * Appelé après chaque analyse comportementale significative.
     * Limite : 1 snapshot max par heure pour ne pas saturer la DB.
     */
    public void saveHistory(PsychProfile p) throws SQLException {
        // Vérifie si un snapshot a déjà été fait dans la dernière heure
        String checkSql = "SELECT COUNT(*) FROM psych_profile_history "
                        + "WHERE user_id=? AND recorded_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)";
        try (PreparedStatement ps = conn().prepareStatement(checkSql)) {
            ps.setInt(1, p.getUserId());
            ResultSet rs = ps.executeQuery();
            if (rs.next() && rs.getInt(1) > 0) return; // Déjà un snapshot récent
        }

        String sql = "INSERT INTO psych_profile_history "
                   + "(user_id,anxiety,resilience,sociability,focus,mood,anomaly_score,detected_type) "
                   + "VALUES (?,?,?,?,?,?,?,?)";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setInt(1, p.getUserId());
            ps.setDouble(2, p.getAnxiety());
            ps.setDouble(3, p.getResilience());
            ps.setDouble(4, p.getSociability());
            ps.setDouble(5, p.getFocus());
            ps.setDouble(6, p.getMood());
            ps.setDouble(7, p.getAnomalyScore());
            ps.setString(8, p.getDetectedType());
            ps.executeUpdate();
        }
    }

    /**
     * Récupère les N derniers snapshots d'un utilisateur (pour le graphique d'évolution).
     */
    public List<PsychProfile> getHistory(int userId, int limit) throws SQLException {
        List<PsychProfile> list = new ArrayList<>();
        String sql = "SELECT * FROM psych_profile_history WHERE user_id=? "
                   + "ORDER BY recorded_at DESC LIMIT ?";
        try (PreparedStatement ps = conn().prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, limit);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                PsychProfile p = mapHistory(rs);
                list.add(p);
            }
        }
        return list;
    }

    // ── Mapping ──────────────────────────────────────────────────────────

    private PsychProfile map(ResultSet rs) throws SQLException {
        PsychProfile p = new PsychProfile();
        p.setId(rs.getInt("id"));
        p.setUserId(rs.getInt("user_id"));
        p.setAnxiety(rs.getDouble("anxiety"));
        p.setResilience(rs.getDouble("resilience"));
        p.setSociability(rs.getDouble("sociability"));
        p.setFocus(rs.getDouble("focus"));
        p.setMood(rs.getDouble("mood"));
        p.setAnomalyScore(rs.getDouble("anomaly_score"));
        p.setDetectedType(rs.getString("detected_type"));
        Timestamp ts = rs.getTimestamp("last_updated");
        if (ts != null) p.setLastUpdated(ts.toLocalDateTime());
        return p;
    }

    private PsychProfile mapHistory(ResultSet rs) throws SQLException {
        PsychProfile p = new PsychProfile();
        p.setUserId(rs.getInt("user_id"));
        p.setAnxiety(rs.getDouble("anxiety"));
        p.setResilience(rs.getDouble("resilience"));
        p.setSociability(rs.getDouble("sociability"));
        p.setFocus(rs.getDouble("focus"));
        p.setMood(rs.getDouble("mood"));
        p.setAnomalyScore(rs.getDouble("anomaly_score"));
        p.setDetectedType(rs.getString("detected_type"));
        Timestamp ts = rs.getTimestamp("recorded_at");
        if (ts != null) p.setLastUpdated(ts.toLocalDateTime());
        return p;
    }
}
