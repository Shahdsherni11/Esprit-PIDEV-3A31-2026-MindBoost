package com.mindboost.models;

import java.time.LocalDateTime;

public class PsychProfile {
    private int id;
    private int userId;
    private double anxiety;      // 0-100
    private double resilience;   // 0-100
    private double sociability;  // 0-100
    private double focus;        // 0-100
    private double mood;         // 0-100
    private double anomalyScore; // 0-100
    private String detectedType;
    private LocalDateTime lastUpdated;

    public PsychProfile() {
        this.anxiety     = 50;
        this.resilience  = 50;
        this.sociability = 50;
        this.focus       = 50;
        this.mood        = 50;
        this.anomalyScore = 0;
        this.detectedType = "ANALYTIQUE";
    }

    public PsychProfile(int userId) {
        this();
        this.userId = userId;
    }

    /**
     * Recalcule le type dominant en comparant correctement les doubles.
     * On prend le score le plus élevé parmi les 5 dimensions.
     * En cas d'égalité stricte, on priorise dans l'ordre défini.
     */
    public void recalculateType() {
        // Tableau : valeur → nom du type
        double[] scores = { focus, resilience, sociability, mood, anxiety };
        String[] types  = { "ANALYTIQUE", "LEADER", "SOCIAL", "CREATIF", "EMPATHIQUE" };

        int bestIdx = 0;
        for (int i = 1; i < scores.length; i++) {
            if (scores[i] > scores[bestIdx]) bestIdx = i;
        }
        // Seuil minimum : si rien ne sort du lot (tout ≤ 55), reste ANALYTIQUE
        detectedType = scores[bestIdx] > 52 ? types[bestIdx] : "ANALYTIQUE";
    }

    /**
     * Score d'anomalie réel :
     * - Anxiété très haute (>70) = signal fort
     * - Mood très bas (<30) = signal fort
     * - Écart-type élevé entre les 5 dimensions = instabilité
     */
    public void recalculateAnomaly() {
        double[] vals = { anxiety, resilience, sociability, focus, mood };
        double mean = 0;
        for (double v : vals) mean += v;
        mean /= vals.length;

        // Écart-type des 5 dimensions
        double variance = 0;
        for (double v : vals) variance += (v - mean) * (v - mean);
        double stddev = Math.sqrt(variance / vals.length);

        // Facteurs critiques
        double anxietyFactor = anxiety > 70 ? (anxiety - 70) * 1.5 : 0;
        double moodFactor    = mood    < 30 ? (30 - mood)    * 1.5 : 0;
        double instability   = stddev > 15  ? (stddev - 15)  * 0.8 : 0;

        this.anomalyScore = Math.min(100, anxietyFactor + moodFactor + instability);
    }

    public String getAlertMessage() {
        if (anomalyScore >= 70) return "🚨 CRITIQUE : Score d'anomalie " + (int)anomalyScore + "%. Intervention recommandée.";
        if (anomalyScore >= 45) return "⚠️ ATTENTION : Profil instable détecté (score " + (int)anomalyScore + "%).";
        return null;
    }

    // Getters / Setters
    public int getId()              { return id; }          public void setId(int id)                { this.id = id; }
    public int getUserId()          { return userId; }      public void setUserId(int u)              { this.userId = u; }
    public double getAnxiety()      { return anxiety; }     public void setAnxiety(double v)          { this.anxiety     = clamp(v); }
    public double getResilience()   { return resilience; }  public void setResilience(double v)       { this.resilience  = clamp(v); }
    public double getSociability()  { return sociability; } public void setSociability(double v)      { this.sociability = clamp(v); }
    public double getFocus()        { return focus; }       public void setFocus(double v)            { this.focus       = clamp(v); }
    public double getMood()         { return mood; }        public void setMood(double v)             { this.mood        = clamp(v); }
    public double getAnomalyScore() { return anomalyScore; }public void setAnomalyScore(double v)    { this.anomalyScore = clamp(v); }
    public String getDetectedType() { return detectedType; }public void setDetectedType(String v)    { this.detectedType = v; }
    public LocalDateTime getLastUpdated()              { return lastUpdated; }
    public void setLastUpdated(LocalDateTime v)        { this.lastUpdated = v; }

    /** Garde une valeur dans [0, 100] */
    private double clamp(double v) { return Math.max(0, Math.min(100, v)); }
}
