package com.mindboost.controllers;

import com.mindboost.dao.PsychProfileDAO;
import com.mindboost.dao.ProfileDAO;
import com.mindboost.dao.UserDAO;
import com.mindboost.models.Profile;
import com.mindboost.models.PsychProfile;
import com.mindboost.models.User;
import com.mindboost.services.AdaptiveUIService;
import com.mindboost.services.PersonalityEngineService;
import com.mindboost.utils.SceneManager;
import com.mindboost.utils.SessionManager;
import com.mindboost.utils.ValidationUtils;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.sql.SQLException;

/**
 * Dashboard principal utilisateur.
 *
 * TRACKING COMPORTEMENTAL — points de collecte couverts :
 *  - recordNavigation() : TOUS les changements d'écran
 *  - recordClick()      : TOUS les boutons importants
 *  - recordKeyPress()   : TOUS les champs texte (profil, compte, mot de passe)
 *
 * Analyse auto périodique toutes les 5 min + analyse manuelle à l'ouverture de PsychMap.
 */
public class UserDashboardController {

    @FXML private Label welcomeLabel;
    @FXML private Label pageSubtitle;
    @FXML private Label userEmailLabel;
    @FXML private Label userRoleLabel;
    @FXML private Label accountEmailDisplay;
    @FXML private Label accountRoleDisplay;
    @FXML private Label accountCreatedDisplay;
    @FXML private Label profileNameDisplay;
    @FXML private Label profileTypeDisplay;
    @FXML private Label profilePhoneDisplay;
    @FXML private Label psychTypeDisplay;
    @FXML private Label psychScoreDisplay;
    @FXML private Label psychTypeLabel;
    @FXML private Label anomalyIndicator;
    @FXML private VBox  psychIndicator;
    @FXML private VBox  dynamicContent;
    @FXML private HBox  homeCards;
    @FXML private HBox  quickActions;

    private final UserDAO         userDAO    = new UserDAO();
    private final ProfileDAO      profileDAO = new ProfileDAO();
    private final PsychProfileDAO psychDAO   = new PsychProfileDAO();

    private User         currentUser;
    private Profile      currentProfile;
    private PsychProfile psychProfile;

    // 🧬 Moteur comportemental — actif pendant toute la session
    private PersonalityEngineService personalityEngine;

    // ──────────────────────────────────────────────────────────────────────

    @FXML
    public void initialize() {
        currentUser = SessionManager.getInstance().getCurrentUser();
        if (currentUser == null) { SceneManager.switchTo("/com/mindboost/fxml/Login.fxml"); return; }
        if ("admin".equals(currentUser.getRole())) { SceneManager.switchTo("/com/mindboost/fxml/AdminDashboard.fxml"); return; }

        // Démarre le moteur avec analyse auto toutes les 5 minutes
        personalityEngine = new PersonalityEngineService(currentUser.getId());
        personalityEngine.startPeriodicAnalysis(updatedProfile -> {
            psychProfile = updatedProfile;
            refreshPsychSidebar();
        });

        refreshProfile();
        refreshPsychProfile();
        updateHeader();
        applyAdaptiveTheme();
    }

    // ── Thème adaptatif ──────────────────────────────────────────────────

    /**
     * Applique réellement le thème CSS adaptatif à la Scene courante.
     * Le thème change la couleur d'accent de la sidebar et des boutons.
     */
    private void applyAdaptiveTheme() {
        if (psychProfile == null) return;
        AdaptiveUIService.UITheme theme = AdaptiveUIService.determineTheme(psychProfile);

        // On passe par Platform.runLater pour s'assurer que la Scene est montée
        Platform.runLater(() -> {
            try {
                Scene scene = dynamicContent != null ? dynamicContent.getScene() : null;
                if (scene == null) return;

                // On utilise un style inline sur le root plutôt qu'une feuille complète
                // pour ne pas écraser le CSS principal
                String accentColor = switch (theme) {
                    case CALM_BLUE     -> "#2980B9";
                    case ENERGETIC_RED -> "#E74C3C";
                    case FOCUS_GREEN   -> "#27AE60";
                    case WARM_ORANGE   -> "#E67E22";
                    case DEEP_PURPLE   -> "#6C63FF";
                };

                // Applique l'accent comme variable CSS sur le root
                scene.getRoot().setStyle(
                    "-fx-accent: " + accentColor + ";"
                );

                System.out.println("🎨 Thème adaptatif appliqué : " + theme + " (accent=" + accentColor + ")");
            } catch (Exception e) {
                System.err.println("Thème non appliqué : " + e.getMessage());
            }
        });
    }

    // ── Profil psy ───────────────────────────────────────────────────────

    private void refreshPsychProfile() {
        try {
            psychProfile = psychDAO.getByUserId(currentUser.getId());
            if (psychProfile == null) {
                psychProfile = new PsychProfile(currentUser.getId());
                psychDAO.save(psychProfile);
            }
            refreshPsychSidebar();
        } catch (Exception e) { e.printStackTrace(); }
    }

    private void refreshPsychSidebar() {
        if (psychProfile == null) return;
        if (psychIndicator != null) psychIndicator.setVisible(true);

        if (psychTypeLabel != null) psychTypeLabel.setText(psychProfile.getDetectedType());

        if (psychTypeDisplay != null) {
            String emoji = switch (psychProfile.getDetectedType() != null ? psychProfile.getDetectedType() : "") {
                case "ANALYTIQUE" -> "🔬";
                case "CREATIF"    -> "🎨";
                case "SOCIAL"     -> "💬";
                case "EMPATHIQUE" -> "💙";
                case "LEADER"     -> "👑";
                default           -> "🧠";
            };
            psychTypeDisplay.setText(emoji + " " + psychProfile.getDetectedType());
        }

        if (psychScoreDisplay != null) {
            double anomaly = psychProfile.getAnomalyScore();
            String txt   = anomaly >= 70 ? "🚨 Anomalie critique !"
                         : anomaly >= 50 ? "⚠️ Anomalie détectée"
                         : "✅ Profil stable";
            String color = anomaly >= 70 ? "#E74C3C" : anomaly >= 50 ? "#F39C12" : "#2ECC71";
            psychScoreDisplay.setText(txt);
            psychScoreDisplay.setStyle("-fx-text-fill:" + color + ";-fx-font-size:12px;");
        }

        if (anomalyIndicator != null) {
            double anomaly = psychProfile.getAnomalyScore();
            if (anomaly >= 50) {
                anomalyIndicator.setText("⚠️ " + (int)anomaly + "% anomalie");
                anomalyIndicator.setStyle("-fx-text-fill:#F39C12;-fx-font-size:10px;");
            } else {
                anomalyIndicator.setText("");
            }
        }

        if (welcomeLabel != null) {
            String name = currentProfile != null ? currentProfile.getFirstName()
                                                 : currentUser.getEmail().split("@")[0];
            welcomeLabel.setText(AdaptiveUIService.getPersonalizedWelcome(psychProfile, name));
        }

        // Réapplique le thème si le profil a changé
        applyAdaptiveTheme();
    }

    // ── Navigation ───────────────────────────────────────────────────────

    @FXML
    public void showHome() {
        engine().recordNavigation("home");
        engine().recordClick("nav_home");
        dynamicContent.getChildren().clear();
        if (homeCards   != null) homeCards.setVisible(true);
        if (quickActions != null) quickActions.setVisible(true);
    }

    @FXML
    public void showPsychMap() {
        engine().recordNavigation("psych_map");
        engine().recordClick("nav_psychmap");
        clearContent();
        // Déclenche une analyse immédiate avant d'afficher la carte
        runBehaviorAnalysis();
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/mindboost/fxml/PsychMap.fxml"));
            Node node = loader.load();
            dynamicContent.getChildren().add(node);
        } catch (Exception e) {
            showError("Erreur chargement Carte Psy : " + e.getMessage());
        }
    }

    @FXML
    public void showMindBot() {
        engine().recordNavigation("mindbot");
        engine().recordClick("nav_mindbot");
        clearContent();
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/mindboost/fxml/MindBotChat.fxml"));
            Node node = loader.load();
            dynamicContent.getChildren().add(node);
        } catch (Exception e) {
            showError("Erreur chargement MindBot : " + e.getMessage());
        }
    }

    @FXML
    public void showMyProfile() {
        engine().recordNavigation("profile");
        engine().recordClick("nav_profile");
        clearContent();
        refreshProfile();

        VBox card = new VBox(14); card.getStyleClass().add("form-container"); card.setMaxWidth(620);
        Label title = new Label("👤  Mon Profil"); title.getStyleClass().add("section-title");
        card.getChildren().add(title);

        if (currentProfile != null) {
            addRow(card, "Prénom",       currentProfile.getFirstName());
            addRow(card, "Nom",          currentProfile.getLastName());
            addRow(card, "Téléphone",    nvl(currentProfile.getPhone()));
            addRow(card, "Personnalité", nvl(currentProfile.getPersonalityType()));
            addRow(card, "Bio",          nvl(currentProfile.getBio()));

            HBox btns = new HBox(12);
            Button editBtn = new Button("✏️  Modifier"); editBtn.getStyleClass().add("btn-primary");
            editBtn.setOnAction(e -> { engine().recordClick("edit_profile"); showEditProfile(); });
            Button delBtn = new Button("🗑  Supprimer"); delBtn.getStyleClass().add("btn-danger");
            delBtn.setOnAction(e -> { engine().recordClick("delete_profile"); deleteMyProfile(); });
            btns.getChildren().addAll(editBtn, delBtn);
            card.getChildren().add(btns);
        } else {
            Label info = new Label("Vous n'avez pas encore créé votre profil.");
            info.setStyle("-fx-text-fill:#9B9BB0;");
            Button createBtn = new Button("➕  Créer mon profil"); createBtn.getStyleClass().add("btn-primary");
            createBtn.setOnAction(e -> { engine().recordClick("create_profile"); showEditProfile(); });
            card.getChildren().addAll(info, createBtn);
        }
        dynamicContent.getChildren().add(card);
    }

    @FXML
    public void showEditProfile() {
        engine().recordNavigation("edit_profile");
        clearContent();
        refreshProfile();

        VBox form = new VBox(16); form.getStyleClass().add("form-container"); form.setMaxWidth(580);
        Label title = new Label(currentProfile == null ? "➕  Créer mon Profil" : "✏️  Modifier mon Profil");
        title.getStyleClass().add("section-title");

        TextField fnField    = field(currentProfile != null ? currentProfile.getFirstName() : "", "Prénom");
        TextField lnField    = field(currentProfile != null ? currentProfile.getLastName()  : "", "Nom");
        TextField phoneField = field(currentProfile != null ? nvlEmpty(currentProfile.getPhone()) : "", "+21612345678");

        ComboBox<String> typeCombo = new ComboBox<>();
        typeCombo.getItems().addAll("INTJ","INTP","ENTJ","ENTP","INFJ","INFP","ENFJ","ENFP",
                                    "ISTJ","ISFJ","ESTJ","ESFJ","ISTP","ISFP","ESTP","ESFP");
        typeCombo.getStyleClass().add("form-combo"); typeCombo.setPrefWidth(540);
        if (currentProfile != null && currentProfile.getPersonalityType() != null)
            typeCombo.setValue(currentProfile.getPersonalityType());

        TextArea bioArea = new TextArea(currentProfile != null ? nvlEmpty(currentProfile.getBio()) : "");
        bioArea.getStyleClass().add("form-area"); bioArea.setPrefRowCount(3);

        Label errLbl = new Label(); errLbl.getStyleClass().add("error-label"); errLbl.setVisible(false);
        Label okLbl  = new Label(); okLbl.getStyleClass().add("success-label");  okLbl.setVisible(false);

        Button saveBtn = new Button(currentProfile == null ? "➕  Créer" : "💾  Sauvegarder");
        saveBtn.getStyleClass().add("btn-primary");

        // ── Tracking frappe sur TOUS les champs ──
        fnField.setOnKeyTyped(e    -> engine().recordKeyPress());
        lnField.setOnKeyTyped(e    -> engine().recordKeyPress());
        phoneField.setOnKeyTyped(e -> engine().recordKeyPress());
        bioArea.setOnKeyTyped(e    -> engine().recordKeyPress());

        typeCombo.setOnAction(e -> engine().recordClick("combo_personality_type"));

        saveBtn.setOnAction(e -> {
            engine().recordClick("save_profile");
            String err = ValidationUtils.validateProfile(fnField.getText().trim(),
                lnField.getText().trim(), phoneField.getText().trim(), "");
            if (err != null) { errLbl.setText(err); errLbl.setVisible(true); return; }
            try {
                if (currentProfile == null) {
                    Profile p = new Profile(currentUser.getId(),
                        fnField.getText().trim(), lnField.getText().trim());
                    p.setPhone(phoneField.getText().trim().isEmpty() ? null : phoneField.getText().trim());
                    p.setPersonalityType(typeCombo.getValue());
                    p.setBio(bioArea.getText().trim().isEmpty() ? null : bioArea.getText().trim());
                    profileDAO.addProfile(p);
                } else {
                    currentProfile.setFirstName(fnField.getText().trim());
                    currentProfile.setLastName(lnField.getText().trim());
                    currentProfile.setPhone(phoneField.getText().trim().isEmpty() ? null : phoneField.getText().trim());
                    currentProfile.setPersonalityType(typeCombo.getValue());
                    currentProfile.setBio(bioArea.getText().trim().isEmpty() ? null : bioArea.getText().trim());
                    profileDAO.updateProfile(currentProfile);
                }
                refreshProfile(); updateHeader();
                okLbl.setText("✅ Profil sauvegardé !"); okLbl.setVisible(true); errLbl.setVisible(false);
            } catch (SQLException ex) { errLbl.setText("Erreur : " + ex.getMessage()); errLbl.setVisible(true); }
        });

        form.getChildren().addAll(title,
            lbl("Prénom *"), fnField, lbl("Nom *"), lnField,
            lbl("Téléphone"), phoneField, lbl("Type MBTI"), typeCombo,
            lbl("Bio"), bioArea, errLbl, okLbl, saveBtn);
        dynamicContent.getChildren().add(form);
    }

    @FXML
    public void showMyAccount() {
        engine().recordNavigation("account");
        engine().recordClick("nav_account");
        clearContent();

        VBox form = new VBox(16); form.getStyleClass().add("form-container"); form.setMaxWidth(560);
        Label title = new Label("👤  Mon Compte"); title.getStyleClass().add("section-title");
        addRow(form, "Email", currentUser.getEmail());
        addRow(form, "Rôle",  currentUser.getRole().toUpperCase());

        TextField newEmailField = field(currentUser.getEmail(), "nouveau@email.com");
        newEmailField.setOnKeyTyped(e -> engine().recordKeyPress());

        Label errLbl = new Label(); errLbl.getStyleClass().add("error-label"); errLbl.setVisible(false);
        Label okLbl  = new Label(); okLbl.getStyleClass().add("success-label");  okLbl.setVisible(false);

        Button updateBtn = new Button("💾  Mettre à jour"); updateBtn.getStyleClass().add("btn-primary");
        updateBtn.setOnAction(e -> {
            engine().recordClick("update_email");
            try {
                String newEmail = newEmailField.getText().trim();
                if (!ValidationUtils.isValidEmail(newEmail)) { errLbl.setText("Email invalide."); errLbl.setVisible(true); return; }
                currentUser.setEmail(newEmail); userDAO.updateUser(currentUser);
                okLbl.setText("✅ Email mis à jour !"); okLbl.setVisible(true);
            } catch (Exception ex) { errLbl.setText(ex.getMessage()); errLbl.setVisible(true); }
        });

        Button deleteBtn = new Button("🗑  Supprimer mon compte"); deleteBtn.getStyleClass().add("btn-danger");
        deleteBtn.setOnAction(e -> {
            engine().recordClick("delete_account");
            Alert a = new Alert(Alert.AlertType.CONFIRMATION,
                "Supprimer votre compte définitivement ?", ButtonType.YES, ButtonType.NO);
            a.showAndWait().ifPresent(btn -> {
                if (btn == ButtonType.YES) {
                    try {
                        personalityEngine.stop();
                        userDAO.deleteUser(currentUser.getId());
                        SessionManager.getInstance().logout();
                        SceneManager.switchTo("/com/mindboost/fxml/Login.fxml");
                    } catch (SQLException ex) { ex.printStackTrace(); }
                }
            });
        });

        form.getChildren().addAll(title, lbl("Modifier email"), newEmailField,
            errLbl, okLbl, updateBtn, new Separator(), deleteBtn);
        dynamicContent.getChildren().add(form);
    }

    @FXML
    public void showChangePassword() {
        engine().recordNavigation("change_password");
        engine().recordClick("nav_password");
        clearContent();

        VBox form = new VBox(16); form.getStyleClass().add("form-container"); form.setMaxWidth(500);
        Label title = new Label("🔐  Changer le Mot de Passe"); title.getStyleClass().add("section-title");

        PasswordField curField  = pwd("Mot de passe actuel");
        PasswordField newField  = pwd("Nouveau mot de passe");
        PasswordField confField = pwd("Confirmer");

        curField.setOnKeyTyped(e  -> engine().recordKeyPress());
        newField.setOnKeyTyped(e  -> engine().recordKeyPress());
        confField.setOnKeyTyped(e -> engine().recordKeyPress());

        Label errLbl = new Label(); errLbl.getStyleClass().add("error-label"); errLbl.setVisible(false);
        Label okLbl  = new Label(); okLbl.getStyleClass().add("success-label");  okLbl.setVisible(false);

        Button saveBtn = new Button("💾  Mettre à jour"); saveBtn.getStyleClass().add("btn-primary");
        saveBtn.setOnAction(e -> {
            engine().recordClick("save_password");
            try {
                if (userDAO.authenticate(currentUser.getEmail(), curField.getText()) == null) {
                    errLbl.setText("Mot de passe actuel incorrect."); errLbl.setVisible(true); return;
                }
                if (!ValidationUtils.isValidPassword(newField.getText())) {
                    errLbl.setText("Mot de passe invalide."); errLbl.setVisible(true); return;
                }
                if (!newField.getText().equals(confField.getText())) {
                    errLbl.setText("Les mots de passe ne correspondent pas."); errLbl.setVisible(true); return;
                }
                userDAO.updatePassword(currentUser.getId(), newField.getText());
                okLbl.setText("✅ Mot de passe mis à jour !"); okLbl.setVisible(true);
            } catch (Exception ex) { errLbl.setText(ex.getMessage()); errLbl.setVisible(true); }
        });

        form.getChildren().addAll(title, lbl("Actuel"), curField,
            lbl("Nouveau"), newField, lbl("Confirmer"), confField,
            errLbl, okLbl, saveBtn);
        dynamicContent.getChildren().add(form);
    }

    @FXML
    public void handleLogout() {
        engine().recordClick("logout");
        // Lance une dernière analyse avant de quitter
        try { personalityEngine.analyzeAndUpdate(); } catch (Exception ignored) {}
        personalityEngine.stop();
        SessionManager.getInstance().logout();
        SceneManager.switchTo("/com/mindboost/fxml/Login.fxml");
    }

    // ── Analyse comportementale ──────────────────────────────────────────

    /** Lance une analyse immédiate en arrière-plan */
    public void runBehaviorAnalysis() {
        new Thread(() -> {
            try {
                psychProfile = personalityEngine.analyzeAndUpdate();
                Platform.runLater(this::refreshPsychSidebar);
            } catch (Exception e) { e.printStackTrace(); }
        }, "behavior-analysis").start();
    }

    // ── Utilitaires ───────────────────────────────────────────────────────

    /** Raccourci nul-safe vers le moteur */
    private PersonalityEngineService engine() {
        return personalityEngine != null ? personalityEngine : new PersonalityEngineService(-1);
    }

    private void clearContent() {
        dynamicContent.getChildren().clear();
        if (homeCards    != null) homeCards.setVisible(false);
        if (quickActions != null) quickActions.setVisible(false);
    }

    private void refreshProfile() {
        try {
            currentProfile = profileDAO.getByUserId(currentUser.getId());
            SessionManager.getInstance().setCurrentProfile(currentProfile);
        } catch (SQLException e) { e.printStackTrace(); }
    }

    private void updateHeader() {
        String name = currentProfile != null
            ? currentProfile.getFirstName()
            : currentUser.getEmail().split("@")[0];
        if (welcomeLabel != null && psychProfile == null)
            welcomeLabel.setText("Bienvenue, " + name + " ! 🌟");
        if (userEmailLabel != null) userEmailLabel.setText(currentUser.getEmail());
        if (userRoleLabel  != null) userRoleLabel.setText(currentUser.getRole().toUpperCase());
        if (accountEmailDisplay != null) accountEmailDisplay.setText(currentUser.getEmail());
        if (accountRoleDisplay  != null) {
            accountRoleDisplay.setText(currentUser.getRole().toUpperCase());
            accountRoleDisplay.setStyle("-fx-text-fill:" + roleColor(currentUser.getRole())
                + ";-fx-font-size:14px;-fx-font-weight:bold;");
        }
        if (accountCreatedDisplay != null && currentUser.getCreatedAt() != null)
            accountCreatedDisplay.setText("Membre depuis : " + currentUser.getCreatedAt().toLocalDate());

        if (currentProfile != null) {
            if (profileNameDisplay != null) profileNameDisplay.setText(currentProfile.getFullName());
            if (profileTypeDisplay != null) profileTypeDisplay.setText(
                currentProfile.getPersonalityType() != null ? "🧠 " + currentProfile.getPersonalityType() : "Type non défini");
            if (profilePhoneDisplay != null) profilePhoneDisplay.setText(
                currentProfile.getPhone() != null ? "📞 " + currentProfile.getPhone() : "Téléphone non renseigné");
        }
    }

    private void deleteMyProfile() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, "Supprimer votre profil ?", ButtonType.YES, ButtonType.NO);
        alert.showAndWait().ifPresent(btn -> {
            if (btn == ButtonType.YES) {
                try {
                    profileDAO.deleteProfile(currentProfile.getId());
                    currentProfile = null;
                    updateHeader();
                    showMyProfile();
                } catch (SQLException e) { e.printStackTrace(); }
            }
        });
    }

    private void addRow(VBox p, String l, String v) {
        HBox row = new HBox(16); row.setAlignment(Pos.CENTER_LEFT);
        row.setStyle("-fx-padding:8 0;-fx-border-color:transparent transparent rgba(255,255,255,0.06) transparent;-fx-border-width:1;");
        Label lbl = new Label(l + " :"); lbl.setStyle("-fx-text-fill:#9B9BB0;-fx-font-size:13px;-fx-min-width:160;");
        Label val = new Label(v != null ? v : "—"); val.setStyle("-fx-text-fill:white;-fx-font-size:14px;"); val.setWrapText(true);
        row.getChildren().addAll(lbl, val); p.getChildren().add(row);
    }

    private Label       lbl(String t)          { Label l = new Label(t); l.getStyleClass().add("form-label"); return l; }
    private TextField   field(String v, String p) { TextField tf = new TextField(v != null ? v : ""); tf.getStyleClass().add("form-field"); tf.setPromptText(p); return tf; }
    private PasswordField pwd(String p)         { PasswordField pf = new PasswordField(); pf.getStyleClass().add("form-field"); pf.setPromptText(p); return pf; }
    private String      nvl(String s)           { return s != null && !s.isEmpty() ? s : "Non renseigné"; }
    private String      nvlEmpty(String s)      { return s != null ? s : ""; }
    private String      roleColor(String r)     { return switch(r) { case "psychologist" -> "#4ECDC4"; case "admin" -> "#FF6B9D"; default -> "#A89CFF"; }; }
    private void        showError(String msg)   { Label err = new Label("❌ " + msg); err.setStyle("-fx-text-fill:#E74C3C;"); dynamicContent.getChildren().add(err); }
}
