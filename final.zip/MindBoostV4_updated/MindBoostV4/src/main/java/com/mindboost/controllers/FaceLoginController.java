package com.mindboost.controllers;

import com.github.sarxos.webcam.Webcam;
import com.mindboost.dao.FaceEncodingDAO;
import com.mindboost.dao.ProfileDAO;
import com.mindboost.dao.UserDAO;
import com.mindboost.models.FaceEncoding;
import com.mindboost.models.User;
import com.mindboost.services.FaceRecognitionService;
import com.mindboost.utils.SceneManager;
import com.mindboost.utils.SessionManager;
import javafx.animation.*;
import javafx.application.Platform;
import javafx.embed.swing.SwingFXUtils;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.util.Duration;

import java.awt.image.BufferedImage;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

public class FaceLoginController {

    @FXML private ImageView     cameraView;
    @FXML private Label         statusLabel;
    @FXML private Label         countdownLabel;
    @FXML private Button        captureBtn;
    @FXML private Button        enrollBtn;
    @FXML private Button        backBtn;
    @FXML private ProgressBar   progressBar;
    @FXML private Circle        faceCircle;

    private Webcam webcam;
    private ScheduledExecutorService cameraExecutor;
    private final AtomicBoolean faceDetected = new AtomicBoolean(false);
    private final AtomicBoolean running      = new AtomicBoolean(false);
    private final AtomicBoolean busy         = new AtomicBoolean(false); // empêche double-clic

    private final UserDAO         userDAO    = new UserDAO();
    private final ProfileDAO      profileDAO = new ProfileDAO();
    private final FaceEncodingDAO faceDAO    = new FaceEncodingDAO();

    @FXML
    public void initialize() {
        setupCircleAnimation();
        startCamera();
    }

    private void setupCircleAnimation() {
        if (faceCircle == null) return;
        faceCircle.setFill(Color.TRANSPARENT);
        faceCircle.setStroke(Color.web("#6C63FF"));
        faceCircle.setStrokeWidth(3);

        ScaleTransition pulse = new ScaleTransition(Duration.millis(1200), faceCircle);
        pulse.setFromX(0.93); pulse.setToX(1.07);
        pulse.setFromY(0.93); pulse.setToY(1.07);
        pulse.setCycleCount(Animation.INDEFINITE);
        pulse.setAutoReverse(true);
        pulse.play();
    }

    // ── CAMÉRA ────────────────────────────────────────────────────────────

    private void startCamera() {
        setStatus("📷 Initialisation de la caméra...", "#9B9BB0");

        new Thread(() -> {
            try {
                webcam = FaceRecognitionService.openWebcam();
                running.set(true);

                cameraExecutor = Executors.newSingleThreadScheduledExecutor(r -> {
                    Thread t = new Thread(r, "webcam-preview");
                    t.setDaemon(true);
                    return t;
                });
                cameraExecutor.scheduleAtFixedRate(this::updateFrame, 0, 66, TimeUnit.MILLISECONDS);

                Platform.runLater(() ->
                    setStatus("🔍 Positionnez votre visage dans le cadre", "#9B9BB0"));

            } catch (Exception e) {
                Platform.runLater(() ->
                    setStatus("❌ Caméra non disponible : " + e.getMessage()
                        + "\n→ Vérifiez qu'une webcam est branchée.", "#E74C3C"));
            }
        }, "webcam-init").start();
    }

    private void updateFrame() {
        if (!running.get() || busy.get()) return;
        BufferedImage frame = FaceRecognitionService.captureFrame(webcam);
        if (frame == null) return;

        boolean face = FaceRecognitionService.hasFace(frame);
        faceDetected.set(face);

        WritableImage fxImg = SwingFXUtils.toFXImage(frame, null);

        Platform.runLater(() -> {
            if (cameraView != null) cameraView.setImage(fxImg);
            if (face) {
                setStatus("✅ Visage détecté — Cliquez 'Connexion par Visage'", "#2ECC71");
                if (faceCircle != null) faceCircle.setStroke(Color.web("#2ECC71"));
            } else {
                setStatus("🔍 Positionnez votre visage dans le cadre...", "#9B9BB0");
                if (faceCircle != null) faceCircle.setStroke(Color.web("#6C63FF"));
            }
        });
    }

    // ── LOGIN PAR VISAGE ──────────────────────────────────────────────────

    @FXML
    public void handleFaceLogin() {
        if (busy.get()) return;

        // On tente même si faceDetected est false (la détection peut être trop stricte en live)
        // On laisse la capture décider
        busy.set(true);
        if (captureBtn != null) captureBtn.setDisable(true);
        if (progressBar != null) progressBar.setProgress(ProgressBar.INDETERMINATE_PROGRESS);
        setStatus("🔍 Capture et analyse en cours...", "#A89CFF");

        new Thread(() -> {
            try {
                // Capture la meilleure image parmi 3 tentatives
                BufferedImage bestFrame = null;
                for (int attempt = 0; attempt < 3; attempt++) {
                    BufferedImage frame = FaceRecognitionService.captureFrame(webcam);
                    if (frame != null) { bestFrame = frame; break; }
                    Thread.sleep(200);
                }

                if (bestFrame == null) {
                    Platform.runLater(() -> {
                        setStatus("❌ Impossible de capturer une image. Vérifiez la caméra.", "#E74C3C");
                        resetButtons();
                    });
                    return;
                }

                BufferedImage faceRegion = FaceRecognitionService.cropFaceRegion(bestFrame);
                double[] descriptor     = FaceRecognitionService.computeDescriptor(faceRegion);

                List<User> allUsers = userDAO.getAllUsers();
                User recognized    = FaceRecognitionService.recognizeFace(descriptor, allUsers);

                Platform.runLater(() -> {
                    if (progressBar != null) progressBar.setProgress(1.0);
                    if (recognized != null) {
                        setStatus("✅ Bienvenue " + recognized.getEmail() + " !", "#2ECC71");
                        SessionManager.getInstance().setCurrentUser(recognized);
                        try {
                            SessionManager.getInstance()
                                .setCurrentProfile(profileDAO.getByUserId(recognized.getId()));
                        } catch (Exception ignored) {}

                        PauseTransition pause = new PauseTransition(Duration.seconds(1.2));
                        pause.setOnFinished(e -> {
                            stopCamera();
                            if ("admin".equals(recognized.getRole()))
                                SceneManager.switchTo("/com/mindboost/fxml/AdminDashboard.fxml");
                            else
                                SceneManager.switchTo("/com/mindboost/fxml/UserDashboard.fxml");
                        });
                        pause.play();
                    } else {
                        if (progressBar != null) progressBar.setProgress(0);
                        setStatus("❌ Visage non reconnu.\n"
                            + "→ Cliquez 'Enregistrer mon Visage' pour créer votre empreinte.", "#E74C3C");
                        resetButtons();
                    }
                });

            } catch (Exception e) {
                Platform.runLater(() -> {
                    if (progressBar != null) progressBar.setProgress(0);
                    setStatus("⚠️ Erreur : " + e.getMessage(), "#E74C3C");
                    resetButtons();
                });
            }
        }, "face-login").start();
    }

    // ── ENREGISTREMENT VISAGE ─────────────────────────────────────────────

    @FXML
    public void handleEnrollFace() {
        if (busy.get()) return;

        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Enregistrer votre visage");
        dialog.setHeaderText("Associer votre visage à un compte existant");
        dialog.setContentText("Votre email :");

        dialog.showAndWait().ifPresent(email -> {
            if (email == null || email.isBlank()) return;
            busy.set(true);
            if (enrollBtn != null) enrollBtn.setDisable(true);

            new Thread(() -> {
                try {
                    // Vérifie que le compte existe
                    User user = userDAO.getByEmail(email.trim().toLowerCase());
                    if (user == null) {
                        Platform.runLater(() -> {
                            setStatus("❌ Aucun compte trouvé pour : " + email, "#E74C3C");
                            resetButtons();
                        });
                        return;
                    }

                    Platform.runLater(() ->
                        setStatus("✅ Compte trouvé : " + user.getEmail()
                            + "\n📸 Regardez la caméra — capture dans 3 secondes...", "#A89CFF"));

                    // Compte à rebours 3-2-1
                    for (int i = 3; i >= 1; i--) {
                        final String txt = String.valueOf(i);
                        Platform.runLater(() -> {
                            if (countdownLabel != null) countdownLabel.setText(txt);
                        });
                        Thread.sleep(1000);
                    }
                    Platform.runLater(() -> {
                        if (countdownLabel != null) countdownLabel.setText("📸");
                    });
                    Thread.sleep(300);

                    // Capture 3 frames, garde la meilleure (avec le plus de peau)
                    BufferedImage bestFrame = captureBestFrame(3);

                    Platform.runLater(() -> {
                        if (countdownLabel != null) countdownLabel.setText("");
                    });

                    if (bestFrame == null) {
                        Platform.runLater(() -> {
                            setStatus("❌ Impossible de capturer une image. Réessayez.", "#E74C3C");
                            resetButtons();
                        });
                        return;
                    }

                    // Calcule le descripteur et sauvegarde
                    BufferedImage faceRegion = FaceRecognitionService.cropFaceRegion(bestFrame);
                    double[] descriptor      = FaceRecognitionService.computeDescriptor(faceRegion);
                    String   encodingJson    = FaceRecognitionService.descriptorToJson(descriptor);

                    FaceEncoding fe = new FaceEncoding(user.getId(), encodingJson);
                    faceDAO.save(fe);

                    Platform.runLater(() -> {
                        setStatus("✅ Visage enregistré pour " + user.getEmail()
                            + " !\n👁️ Vous pouvez maintenant vous connecter par reconnaissance faciale.", "#2ECC71");
                        resetButtons();
                    });

                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                } catch (Exception e) {
                    Platform.runLater(() -> {
                        if (countdownLabel != null) countdownLabel.setText("");
                        setStatus("⚠️ Erreur : " + e.getMessage(), "#E74C3C");
                        resetButtons();
                    });
                }
            }, "face-enroll").start();
        });
    }

    /**
     * Capture plusieurs frames et retourne la meilleure.
     * La "meilleure" = celle qui n'est pas null (la caméra est fiable avec webcam-capture).
     */
    private BufferedImage captureBestFrame(int attempts) throws InterruptedException {
        BufferedImage best = null;
        for (int i = 0; i < attempts; i++) {
            BufferedImage frame = FaceRecognitionService.captureFrame(webcam);
            if (frame != null) {
                best = frame;
                // Prend la dernière frame (plus récente = meilleure lumière)
            }
            if (i < attempts - 1) Thread.sleep(150);
        }
        return best;
    }

    // ── NAVIGATION ────────────────────────────────────────────────────────

    @FXML
    public void handleBack() {
        stopCamera();
        SceneManager.switchTo("/com/mindboost/fxml/Login.fxml");
    }

    // ── UTILITAIRES ───────────────────────────────────────────────────────

    private void setStatus(String msg, String colorHex) {
        Platform.runLater(() -> {
            if (statusLabel == null) return;
            statusLabel.setText(msg);
            statusLabel.setStyle("-fx-text-fill:" + colorHex + ";-fx-font-size:13px;");
        });
    }

    private void resetButtons() {
        busy.set(false);
        if (captureBtn != null) captureBtn.setDisable(false);
        if (enrollBtn  != null) enrollBtn.setDisable(false);
        if (progressBar != null) progressBar.setProgress(0);
    }

    /** Arrête proprement la caméra et le thread de preview */
    public void stopCamera() {
        running.set(false);
        busy.set(false);
        if (cameraExecutor != null && !cameraExecutor.isShutdown()) {
            cameraExecutor.shutdownNow();
            cameraExecutor = null;
        }
        if (webcam != null && webcam.isOpen()) {
            new Thread(() -> {
                try { webcam.close(); } catch (Exception ignored) {}
            }, "webcam-close").start();
        }
        webcam = null;
    }
}
