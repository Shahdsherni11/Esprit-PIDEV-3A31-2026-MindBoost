package com.mindboost.services;

import com.github.sarxos.webcam.Webcam;
import com.google.gson.Gson;
import com.mindboost.dao.FaceEncodingDAO;
import com.mindboost.models.FaceEncoding;
import com.mindboost.models.User;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.List;

/**
 * 👁️ Service de reconnaissance faciale
 * Détection robuste par analyse multi-critères de la peau
 */
public class FaceRecognitionService {

    // ── Seuils ajustables ──────────────────────────────────────────────────
    /** Seuil de détection : % minimum de pixels peau dans la zone centrale */
    private static final double SKIN_THRESHOLD     = 0.08;  // 8% (était 15% — trop strict)

    /** Seuil de reconnaissance : distance euclidienne max pour valider */
    private static final double MATCH_THRESHOLD    = 0.75;  // 0.75 (était 0.50 — trop strict)

    // ──────────────────────────────────────────────────────────────────────

    /** Ouvre et retourne la webcam par défaut */
    public static Webcam openWebcam() {
        Webcam webcam = Webcam.getDefault();
        if (webcam == null) throw new RuntimeException("Aucune webcam trouvée.");
        webcam.setViewSize(new Dimension(640, 480));
        if (!webcam.isOpen()) webcam.open();
        return webcam;
    }

    /** Capture une image depuis la webcam ouverte */
    public static BufferedImage captureFrame(Webcam webcam) {
        if (webcam == null || !webcam.isOpen()) return null;
        return webcam.getImage();
    }

    /**
     * Détecte si un visage est présent dans l'image.
     * Utilise une analyse multi-zone et des critères de peau larges
     * pour fonctionner avec toutes les carnations et éclairages.
     */
    public static boolean hasFace(BufferedImage img) {
        if (img == null) return false;
        int w = img.getWidth(), h = img.getHeight();

        // Analyse 3 zones : centre, centre-haut, centre-milieu
        int[][] zones = {
            { w / 4,     h / 5,     w / 2, 3 * h / 5 },  // zone principale
            { w * 3/8,   h / 8,     w / 4, h / 2      },  // zone visage haute
            { w / 3,     h / 4,     w / 3, h / 2      },  // zone centrale
        };

        for (int[] zone : zones) {
            int startX = zone[0], startY = zone[1], zw = zone[2], zh = zone[3];
            // Garde dans les bornes
            startX = Math.max(0, Math.min(startX, w - 1));
            startY = Math.max(0, Math.min(startY, h - 1));
            int endX = Math.min(startX + zw, w);
            int endY = Math.min(startY + zh, h);

            int skinPixels = 0, total = 0;
            for (int x = startX; x < endX; x += 3) {
                for (int y = startY; y < endY; y += 3) {
                    if (isSkinColor(new Color(img.getRGB(x, y)))) skinPixels++;
                    total++;
                }
            }
            if (total > 0 && (double) skinPixels / total > SKIN_THRESHOLD) {
                return true;  // Au moins une zone a assez de pixels peau
            }
        }
        return false;
    }

    /**
     * Détecte une couleur de peau.
     * Critères larges pour couvrir toutes les carnations (claire à foncée)
     * et différentes conditions d'éclairage.
     */
    private static boolean isSkinColor(Color c) {
        int r = c.getRed(), g = c.getGreen(), b = c.getBlue();

        // Critère 1 : teinte RGB classique (carnations claires à moyennes)
        boolean rgb1 = r > 80 && g > 40 && b > 20
            && r > g && r > b
            && (r - g) > 10
            && (r - b) > 10
            && r < 255;

        // Critère 2 : rapport chromatique (carnations plus foncées)
        float total = r + g + b;
        boolean rgb2 = total > 60
            && ((float) r / total) > 0.35f
            && ((float) g / total) > 0.25f
            && ((float) b / total) < 0.35f;

        // Critère 3 : modèle YCbCr (robuste aux variations d'éclairage)
        double y  =  0.299 * r + 0.587 * g + 0.114 * b;
        double cb = -0.169 * r - 0.331 * g + 0.500 * b + 128;
        double cr =  0.500 * r - 0.419 * g - 0.081 * b + 128;
        boolean ycbcr = y > 40 && cb >= 77 && cb <= 127 && cr >= 133 && cr <= 173;

        return rgb1 || rgb2 || ycbcr;
    }

    /**
     * Calcule un descripteur unique du visage (128 valeurs).
     * Basé sur histogramme + variance + gradient par zone.
     * Plus robuste que la version précédente.
     */
    public static double[] computeDescriptor(BufferedImage img) {
        if (img == null) return new double[128];

        // Normalise à 64x64 pour une empreinte stable
        BufferedImage normalized = new BufferedImage(64, 64, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2 = normalized.createGraphics();
        g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                            RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g2.drawImage(img, 0, 0, 64, 64, null);
        g2.dispose();

        // Convertit en niveaux de gris normalisés
        double[][] gray = new double[64][64];
        for (int x = 0; x < 64; x++) {
            for (int y = 0; y < 64; y++) {
                Color c = new Color(normalized.getRGB(x, y));
                gray[x][y] = (0.299 * c.getRed()
                            + 0.587 * c.getGreen()
                            + 0.114 * c.getBlue()) / 255.0;
            }
        }

        double[] descriptor = new double[128];
        int idx = 0;

        // Grille 8x8 blocs de 8x8 pixels → 64 blocs → mean + stddev = 128 valeurs
        for (int bx = 0; bx < 8 && idx < 128; bx++) {
            for (int by = 0; by < 8 && idx < 128; by++) {
                double sum = 0, sumSq = 0;
                int count = 0;
                for (int px = bx * 8; px < (bx + 1) * 8; px++) {
                    for (int py = by * 8; py < (by + 1) * 8; py++) {
                        double v = gray[px][py];
                        sum   += v;
                        sumSq += v * v;
                        count++;
                    }
                }
                double mean     = sum / count;
                double variance = Math.max(0, (sumSq / count) - (mean * mean));
                double stddev   = Math.sqrt(variance);

                if (idx < 128) descriptor[idx++] = mean;
                if (idx < 128) descriptor[idx++] = stddev;
            }
        }
        return descriptor;
    }

    /** Extrait la zone centrale (visage probable) d'une image */
    public static BufferedImage cropFaceRegion(BufferedImage img) {
        if (img == null) return null;
        int w = img.getWidth(), h = img.getHeight();
        // Zone centrale élargie : 60% de largeur, 70% de hauteur
        int x  = (int)(w * 0.20);
        int y  = (int)(h * 0.10);
        int fw = (int)(w * 0.60);
        int fh = (int)(h * 0.70);
        // Sécurité bornes
        x  = Math.max(0, Math.min(x,  w - 1));
        y  = Math.max(0, Math.min(y,  h - 1));
        fw = Math.min(fw, w - x);
        fh = Math.min(fh, h - y);
        return img.getSubimage(x, y, fw, fh);
    }

    // ── Sérialisation ──────────────────────────────────────────────────────

    public static String descriptorToJson(double[] d)  { return new Gson().toJson(d); }
    public static double[] jsonToDescriptor(String json) {
        if (json == null || json.isBlank()) return new double[128];
        return new Gson().fromJson(json, double[].class);
    }

    /** Distance euclidienne normalisée entre deux descripteurs */
    public static double distance(double[] a, double[] b) {
        if (a == null || b == null) return Double.MAX_VALUE;
        double sum = 0;
        int len = Math.min(a.length, b.length);
        for (int i = 0; i < len; i++) sum += (a[i] - b[i]) * (a[i] - b[i]);
        return Math.sqrt(sum / len);  // Normalisé par longueur
    }

    /**
     * Reconnaît l'utilisateur parmi tous les encodages en DB.
     * Retourne l'utilisateur si la distance est sous le seuil MATCH_THRESHOLD.
     */
    public static User recognizeFace(double[] descriptor, List<User> allUsers) throws Exception {
        FaceEncodingDAO dao = new FaceEncodingDAO();
        List<FaceEncoding> encodings = dao.getAllEncodings();
        if (encodings.isEmpty()) return null;

        double minDist    = Double.MAX_VALUE;
        int    bestUserId = -1;

        for (FaceEncoding fe : encodings) {
            if (fe.getEncoding() == null) continue;
            double[] stored = jsonToDescriptor(fe.getEncoding());
            double dist = distance(descriptor, stored);
            System.out.printf("  → userId=%d  dist=%.4f%n", fe.getUserId(), dist);
            if (dist < minDist) {
                minDist    = dist;
                bestUserId = fe.getUserId();
            }
        }

        System.out.printf("🔍 Best match: userId=%d  dist=%.4f (seuil=%.2f)%n",
            bestUserId, minDist, MATCH_THRESHOLD);

        if (minDist <= MATCH_THRESHOLD && bestUserId != -1) {
            final int uid = bestUserId;
            return allUsers.stream()
                .filter(u -> u.getId() == uid)
                .findFirst().orElse(null);
        }
        return null;
    }
}
