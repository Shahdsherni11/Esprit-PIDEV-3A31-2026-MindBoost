package com.mindboost.controllers;

import com.mindboost.dao.ProfileDAO;
import com.mindboost.dao.UserDAO;
import com.mindboost.models.User;
import com.mindboost.services.OAuthService;
import com.mindboost.utils.SceneManager;
import com.mindboost.utils.SessionManager;
import com.mindboost.utils.ValidationUtils;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.sql.SQLException;

public class LoginController {

    @FXML private TextField     emailField;
    @FXML private PasswordField passwordField;
    @FXML private Label         errorLabel;
    @FXML private Button        githubBtn;
    @FXML private Button        googleBtn;

    private final UserDAO    userDAO    = new UserDAO();
    private final ProfileDAO profileDAO = new ProfileDAO();

    @FXML
    public void initialize() {
        passwordField.setOnAction(e -> handleLogin());

        // Griser les boutons OAuth si non configurés
        if (githubBtn != null) {
            boolean configured = OAuthService.isGithubConfigured();
            githubBtn.setOpacity(configured ? 1.0 : 0.45);
            githubBtn.setTooltip(new Tooltip(configured
                ? "Se connecter avec GitHub"
                : "GitHub OAuth non configuré — voir config.properties"));
        }
        if (googleBtn != null) {
            boolean configured = OAuthService.isGoogleConfigured();
            googleBtn.setOpacity(configured ? 1.0 : 0.45);
            googleBtn.setTooltip(new Tooltip(configured
                ? "Se connecter avec Google"
                : "Google OAuth non configuré — voir config.properties"));
        }
    }

    // ──────────────────────────────────────────────
    //  Connexion standard email/password
    // ──────────────────────────────────────────────
    @FXML
    public void handleLogin() {
        String email    = emailField.getText().trim();
        String password = passwordField.getText();

        if (!ValidationUtils.isValidEmail(email)) { showError("Email invalide."); return; }
        if (password.isEmpty())                    { showError("Mot de passe requis."); return; }

        try {
            User user = userDAO.authenticate(email, password);
            if (user == null) {
                showError("Email ou mot de passe incorrect.");
                passwordField.clear();
                return;
            }
            connectUser(user);
        } catch (Exception e) {
            showError("Erreur base de données : " + e.getMessage());
        }
    }

    // ──────────────────────────────────────────────
    //  Connexion GitHub OAuth
    // ──────────────────────────────────────────────
    @FXML
    public void handleGithubLogin() {
        showError(""); // reset
        setButtonsDisabled(true);

        new Thread(() -> {
            try {
                OAuthService.OAuthUser oauthUser = OAuthService.loginWithGithub();
                handleOAuthLogin(oauthUser);
            } catch (IllegalStateException e) {
                // Non configuré
                Platform.runLater(() -> {
                    showError("GitHub non configuré :\n" + e.getMessage());
                    setButtonsDisabled(false);
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    showError("Erreur GitHub : " + e.getMessage());
                    setButtonsDisabled(false);
                });
            }
        }).start();
    }

    // ──────────────────────────────────────────────
    //  Connexion Google OAuth
    // ──────────────────────────────────────────────
    @FXML
    public void handleGoogleLogin() {
        showError(""); // reset
        setButtonsDisabled(true);

        new Thread(() -> {
            try {
                OAuthService.OAuthUser oauthUser = OAuthService.loginWithGoogle();
                handleOAuthLogin(oauthUser);
            } catch (IllegalStateException e) {
                Platform.runLater(() -> {
                    showError("Google non configuré :\n" + e.getMessage());
                    setButtonsDisabled(false);
                });
            } catch (Exception e) {
                Platform.runLater(() -> {
                    showError("Erreur Google : " + e.getMessage());
                    setButtonsDisabled(false);
                });
            }
        }).start();
    }

    // ──────────────────────────────────────────────
    //  Traitement après OAuth (créer/récupérer user)
    // ──────────────────────────────────────────────
    private void handleOAuthLogin(OAuthService.OAuthUser oauthUser) {
        Platform.runLater(() -> {
            try {
                // Chercher ou créer l'utilisateur par email OAuth
                User user = userDAO.getByEmail(oauthUser.email);

                if (user == null) {
                    // Premier login OAuth → créer le compte automatiquement
                    user = new User();
                    user.setEmail(oauthUser.email);
                    user.setRole("user");
                    // Mot de passe aléatoire non utilisé (OAuth only)
                    user.setVerified(true);
                    user.setPassword(com.mindboost.utils.PasswordUtils.hashPassword(
                        oauthUser.provider + "_" + oauthUser.providerId + "_" + System.nanoTime()));
                    userDAO.addUser(user);
                    user = userDAO.getByEmail(oauthUser.email);
                }

                if (user != null) {
                    connectUser(user);
                } else {
                    showError("Impossible de créer le compte OAuth. Réessayez.");
                    setButtonsDisabled(false);
                }
            } catch (Exception e) {
                showError("Erreur lors de la connexion OAuth : " + e.getMessage());
                setButtonsDisabled(false);
            }
        });
    }

    // ──────────────────────────────────────────────
    //  Navigation
    // ──────────────────────────────────────────────
    @FXML public void handleFaceLogin() {
        SceneManager.switchTo("/com/mindboost/fxml/FaceLogin.fxml");
    }

    @FXML public void handleRegister() {
        SceneManager.switchTo("/com/mindboost/fxml/Register.fxml");
    }

    // ──────────────────────────────────────────────
    //  Helpers
    // ──────────────────────────────────────────────
    private void connectUser(User user) throws SQLException {
        SessionManager.getInstance().setCurrentUser(user);
        SessionManager.getInstance().setCurrentProfile(profileDAO.getByUserId(user.getId()));

        if ("admin".equals(user.getRole()))
            SceneManager.switchTo("/com/mindboost/fxml/AdminDashboard.fxml");
        else
            SceneManager.switchTo("/com/mindboost/fxml/UserDashboard.fxml");
    }

    private void showError(String msg) {
        if (errorLabel != null) {
            errorLabel.setText(msg);
            errorLabel.setVisible(!msg.isEmpty());
        }
    }

    private void setButtonsDisabled(boolean disabled) {
        if (githubBtn != null) githubBtn.setDisable(disabled);
        if (googleBtn != null) googleBtn.setDisable(disabled);
    }
}
